﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ClassLibrary.Person;

namespace ClassLibrary
{
    
    public class Person : IComparable<Person>, ICloneable, IInit
    {
        private int age;
        private string name;

        public ExampleClone example_Clone; // переделать

        static Random rnd = new Random();
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                if (value >= 0)
                    age = value;
                else
                {
                    throw new ArgumentException(" Возраст человека не может быть меньше 0 ");
                }
            }
        }
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public Person(int age, string name, ExampleClone clone)
        {
            Name = name;
            Age = age;
            this.example_Clone = clone;
        }
        public Person()
        {

        }
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }
        public virtual void Show()
        {
            Console.WriteLine($" Персона: {Name} \n Возраст: {Age}");
        }
        public virtual void Init() // 
        {
            Console.Write("\n Введит Фамилию и Имя человека:");
            Name = Console.ReadLine();
            Console.WriteLine("\n Введите возраст:");
            Age = int.Parse(Console.ReadLine());
        }
        public virtual void RandomInit() // 
        {
            string[] arr = { "Береснев Александр", "Гущян Арам", "Швацкий Даниил", "Кладов Никита", "Виноградова Юлия", "Камалетдинов Максимильян", "Ившин Максим", "Иванов Иван" };
            Name = arr[rnd.Next(0, 7)];
            Age = rnd.Next(18, 30);
        }
        public override bool Equals(object obj)
        {
            if (obj is Person place)
            {
                return place.Age == Age && place.Name == Name;
            }
            return false;
        }


        // переделать
        public int CompareTo(Person person) 
        {
            if (person is null) throw new ArgumentException("Некорректное значение");
            return Age.CompareTo(person.Age);
        }
        public object Clone()
        {
            return new Person(Age, "Клон" + " " + Name, new ExampleClone(example_Clone.Example));
        }
        public Person ShaddowCopy()
        {
            return (Person)this.MemberwiseClone();
        }

        // Штуки
        public class ExampleClone
        {
            public string Example
            {
                get;

                set;
            }
            public ExampleClone(string exampe)
            {
                Example = exampe;
            }
        }
        public interface IInit
        {
            void Init();
            void RandomInit();
            void Show();
        }
        public class WorkWithIInit : IInit
        {
            private string name;
            public string Name
            {
                get
                {
                    return name;
                }
                set
                {
                    name = value;
                }
            }

            public virtual void Init()
            {
                Console.WriteLine("Введите имя");
                Name = Console.ReadLine();
            }

            public virtual void RandomInit()
            {
                string[] arr = { "Тест", "Практика", "Экзамен" };
                Random rnd = new Random();
                Name = arr[rnd.Next(1, 3)];
            }
            public virtual void Show()
            {
                Console.WriteLine($"Название: {Name}");
            }
        }
        public class ComparerPlace : IComparer<Person>
        {
            public int Compare(Person person1, Person person2)
            {
                if (person1 == null || person2 == null)
                {
                    throw new ArgumentNullException("Некорректное значение");
                }
                return person1.Name.CompareTo(person2.Name);
            }
        }
    }
}
