﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClassLibrary
{
    public class Student : Person
    {
        private string group;
        private int course;

        //static Random rnd = new Random();
        public int Course
        {
            get
            {
                return course;
            }
            set
            {
                if (value >= 0 && value < 4)
                {
                    course = value;
                }
                else
                {
                    throw new ArgumentException(" Профессия предполагает 4 года обучения и не может быть меньше 0.");
                }
            }
        }
        public string Group
        {
            get
            {
                return group;
            }
            set
            {
                group = value;
            }
        }
        public Student()
        {

        }
        public Student(int age, string name, string group, int course) : base(name, age)
        {
            Group = group;
            Course = course;
        }
        public override void Show()
        {
            base.Show();
            Console.WriteLine($" Учебная Группа: {Group} \n Курс (год обучения): {Course}\n");
        }
        public override void Init()
        {
            Console.Write("\n Введите название группы:");
            group = Console.ReadLine();
            Console.WriteLine("\n Введите курс (год обучения):");
            course = int.Parse(Console.ReadLine());
        }
        public override void RandomInit()
        {
            base.RandomInit();
            string[] arr = { "РИС", "ИВТ", "РАПР", "ИПР", "САУ"};
            Random rnd = new Random();
            Group = arr[rnd.Next(0, 4)];
            Course = rnd.Next(1, 4);
        }
        public override bool Equals(object obj)
        {
            if (obj is Student student)
            {
                return student.Course == Course && student.Group == Group && base.Equals(obj);
            }
            return false;
        }
    }
}
