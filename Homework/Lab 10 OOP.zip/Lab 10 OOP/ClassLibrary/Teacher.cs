﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Teacher : Employee
    {
        private string discipline;

        //static Random rnd = new Random();
        public string Discipline
        {
            get
            {
                return discipline;
            }
            set
            {
                discipline = value;
            }
        }
        public Teacher()
        {

        }
        public Teacher(int age, string name, string workPlace, string discipline) : base(name, age, workPlace)
        {
            Discipline = discipline;
        }
        public override void Show()
        {
            base.Show();
            Console.Write($" Дисциплина (предмет):{Discipline}\n");
        }
        public override void Init()
        {
            base.Init();
            Console.Write("\n Введите название дисциплины (предмета):");
            Discipline = Console.ReadLine();
        }
        public override void RandomInit()
        {
            base.RandomInit();
            string[] arr = { "Физкультура", "Математика", "Информатика", "Английский язык","Базы Данных" };
            Random rnd = new Random();
            Discipline = arr[rnd.Next(0, 4)];
        }
        public override bool Equals(object obj)
        {
            if (obj is Teacher discipline)
            {
                return discipline.Discipline == Discipline && base.Equals(obj);
            }
            return false;
        }
    }
}
