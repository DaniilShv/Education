﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClassLibrary
{
    public class Employee:Person
    {
        private string workPlace;

        //static Random rnd = new Random();
        public string WorkPlace
        {
            get
            {
                return workPlace;
            }
            set
            {
                workPlace = value;
            }
        }
        public Employee()
        {

        }
        public Employee(string name, int age, string workPlace) : base(name, age)
        {
            WorkPlace = workPlace;
        }
        public override void Show()
        {
            base.Show();
            Console.WriteLine($" Место работы:{WorkPlace}");
        }
        public override void Init()
        {
            base.Init();
            Console.Write("\n Введите место работы:");
            WorkPlace = Console.ReadLine();
        }
        public override void RandomInit()
        {
            base.RandomInit();
            string[] arr = { "ПНИПУ", "ПГНИУ", "ВШЭ", "ПГАТУ" };
            Random rnd = new Random();
            WorkPlace = arr[rnd.Next(0, 3)];
        }
        public override bool Equals(object obj)
        {
            if (obj is Employee workPlace)
            {
                return workPlace.WorkPlace == WorkPlace && base.Equals(obj);
            }
            return false;
        }
    }
}
