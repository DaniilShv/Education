﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10_OOP
{
    internal class Menu
    {
        static Random rnd = new Random();
        static public void ShowMainMenu() 
        {

            int choice;
            do
            {
                Console.Clear();
                Console.Write("_______Лабораторная работа 10_______\n");
                Console.Write(" Выбери пункт:\n 1. Демонстрация элементов\n 2. Работа с Классом-коллекцией\n 0. Выход\n Выберите действие: ");
                choice = Examination();

                switch (choice)
                {
                    case 1:
                        ShowFeatures();
                        break;
                    case 2:
                        
                        break;
                }
            } while (choice != 0);
            Environment.Exit(0);
        }
        static public int Examination() // Проверка на ввод верного значения
        {
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 0)
            {
                Console.Write(" Недопустимое значение.\nВведите число:");
            };
            return choice;
        }
        static public void Pause() // Считывание произвольной клавиши
        {
            Console.WriteLine("\n Нажмите любую клавишу, чтобы продолжить.\n");
            Console.ReadKey();
        }
        static public void ShowFeatures() // просмотр
        {
            int choice;
            //Console.Write("\n Введите количество элементов:");
            //int value = Examination();
            Person[] persons = new Person[4];
            persons = CreateElements(persons);
            Console.WriteLine($"Созданн массив из {4} элементов.");
            do
            {
                Console.Clear();
                Console.Write("_______Просмотр элементов_______\n");
                Console.Write(" Выбери пункт:\n 1. Виртуальная функция\n 2. Невиртуальные функция\n 0. Выход\n Выберите действие: ");
                choice = Examination();
                switch (choice)
                {
                    case 1:
                        ShowVirtual(persons);
                        Pause();
                        break;
                    case 2:
                        ShowNotVirtual(persons);
                        Pause();
                        break;
                }
            } while (choice != 0);
        }
        static void ShowVirtual(Person[] persons) // виртуальная
        {
            Console.Clear();
            Console.WriteLine(" Просмотр элементов массива через виртуальные функции\n");

            foreach (Person person in persons)
            {
                person.Show();
                Console.WriteLine();
            }
        }
        static void ShowNotVirtual(Person[] persons) // не виртуальная
        {
            Console.WriteLine("Просмотр элементов массива через невиртуальные функции\n");
            foreach (Person place in persons)
            {
                
                if (place is Person) place.Show();
                if (place is Employee) place.Show();
                if (place is Teacher) place.Show();
                if (place is Student) place.Show();
                Console.WriteLine();
            }
        }
        static public Person[] CreateElements(Person[] person) // генерация
        {
            //for (int i = 0; i < person.Length; i++)
            //{
            //    int chois = rnd.Next(1, 4);
            //    switch (chois)
            //    {
            //        case 1:
            //            person[i] = new Person();
            //            person[i].RandomInit();
            //            break;
            //        case 2:
            //            person[i] = new Employee();
            //            person[i].RandomInit();
            //            break;
            //        case 3:
            //            person[i] = new Teacher();
            //            person[i].RandomInit();
            //            break;
            //        case 4:
            //            person[i] = new Student();
            //            person[i].RandomInit();
            //            break;
            //    }
            //}

            person[0] = new Person();
            person[0].RandomInit();

            person[1] = new Employee();
            person[1].RandomInit();

            person[2] = new Teacher();
            person[2].RandomInit();

            person[3] = new Student();
            person[3].RandomInit();
            return person;
        }

    }
}
