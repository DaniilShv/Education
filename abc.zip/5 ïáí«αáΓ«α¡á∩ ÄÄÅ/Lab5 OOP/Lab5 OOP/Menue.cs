﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_OOP
{
    internal class Menue
    {
        static public void MainMenue()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.Write("_______Массивы_______\n");
                Console.Write(" Выбери массив:\n 1. Одномерный массив\n 2. Многомерный массив\n 3. Рваный массив\n 0. Выход\n Выберите действие: ");
                choice = Examination();
                switch (choice)
                {
                    case 1:
                        int[] array = { };
                        CreateArray(array);// Одномерный
                        break;
                    case 2:
                        int[,] multiarray = { };
                        CreateMultiArray(multiarray); // Многомерный
                        break;
                    case 3:
                        int[][]tornarray = { };
                        CreateTornArray(tornarray);// Рваный
                        break;
                }
            } while (choice != 0);
            Environment.Exit(0);
        }
        // Обномерный массив
        static public void CreateArray(int[] array) {
            int choice;
            do
            {
                Console.Clear();
                Console.Write($"__Одномерный массив___\n");
                ShowArray(array);
                Console.WriteLine("\n 1. Создать с произвольными элементами\n 2. Создать самому\n 3. Удалить первый чётный элемент\n 0. Назад к выбору массива\n Выберите действие: ");
                choice = Examination();
                switch (choice)
                {
                    case 1:
                        ConclusionInstructions(4);
                        int columns = ExaminationNotZero();
                        array = Arrays.RandArray(columns); // Вызов функции для заполнерия массива произвольными значениями 
                        CreateArray(array);
                        break;
                    case 2:
                        ConclusionInstructions(4);
                        int size = ExaminationNotZero();
                        array = Arrays.FillingArra(size); // Вызов функции для заполнерия массива ручками
                        CreateArray(array);

                        foreach (int element in array)
                        { Console.Write(element + " "); } // Вывод массива
                        break;
                    case 3:
                        ConclusionInstructions(5);
                        array = Arrays.RemoveEven(array);
                        ShowArray(array);
                        Pause();
                        break;
                }
            ConclusionInstructions(6);
            } while (choice != 0) ;
            MainMenue();
        }
        // Многомерный массив
        static public void CreateMultiArray(int[,] multiarray)
       {
            int choice;
            do{
                Console.Clear();
                Console.Write("__Многомерный массив___\n");
                ShowMultiArray(multiarray);
                Console.Write(" 1. Создать с произвольными элементами\n 2. Создать самому\n 3. Добавить строку с указанным номером\n 0. Назад к выбору массива\n Выберите действие: ");
                choice = Examination();
                int row, columns;
                switch (choice)
                {
                    case 1:
                        ConclusionInstructions(3);
                        row = ExaminationNotZero();

                        ConclusionInstructions(2);
                        columns = ExaminationNotZero();

                        multiarray = Arrays.RandArrayMulti(row, columns);// Заполняем массив произвольными числами
                        CreateMultiArray(multiarray);
                        break;
                    case 2:
                        ConclusionInstructions(3);
                        row = ExaminationNotZero();

                        ConclusionInstructions(2);
                        columns = ExaminationNotZero();

                        multiarray = Arrays.FillingMultiArray(row, columns);// Заполнение ручками
                        CreateMultiArray(multiarray);
                        break;
                    case 3:
                        ConclusionInstructions(5);
                        multiarray = Arrays.AddRow(multiarray);
                        ShowMultiArray(multiarray);
                        Pause();
                        break;
                }
                ConclusionInstructions(6);
            } while (choice != 0) ;
            MainMenue();
        }
        // Рваный массив
        static public void CreateTornArray(int[][] tornarray)
        {
            int choice;
            do{
                Console.Clear();
                Console.Write("__Рваный массив___\n");
                ShowTornArray(tornarray);
                Console.Write("\n 1. Создать с произвольными элементами\n 2. Создать самому\n 3. Удалить самую длинную строку\n 0. Назад к выбору массива\n Выберите действие: ");
                choice = Examination();
                int row;
                switch (choice)
                {
                    case 1:
                        ConclusionInstructions(3);
                        row = ExaminationNotZero();

                        tornarray = Arrays.RandArrayRagged(row); // Вызов функции для заполнерия массива произвольными значениями 
                        CreateTornArray(tornarray);

                        break;
                    case 2:
                        ConclusionInstructions(3);
                        row = ExaminationNotZero();

                        tornarray = Arrays.FillingArrayRagged(row); // Вызов функции для заполнерия массива ручками
                        CreateTornArray(tornarray);

                        break;
                    case 3:
                        ConclusionInstructions(5);
                        tornarray = Arrays.DellLongestRow(tornarray);
                        ShowTornArray(tornarray);
                        Pause();
                        break;
                }
                ConclusionInstructions(6);
            } while (choice != 0) ;
            MainMenue();
        }
        static public void ShowArray(int[] array) {
            foreach (int element in array)
            { Console.Write(element + " "); } // Вывод массива
        }
        static public void ShowMultiArray(int[,] multiarray) // Вывод многомерного массива
        {
            int rows = multiarray.GetLength(0);
            int columns = multiarray.GetLength(1);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.Write(multiarray[i, j]+" ");
                }
                Console.WriteLine("\n");
            }
            Console.WriteLine();
        }
        static public void ShowTornArray(int[][] tornarray) // Вывод рваного массива
        {
            int rows = tornarray.GetLength(0);
            for (int i = 0; i < rows; i++)
            {

                for (int j = 0; j < tornarray[i].Length; j++)
                {
                    Console.Write(tornarray[i][j] + " ");
                }
                Console.WriteLine();

            }
        }
        static public int Examination() // Проверка на ввод верного значения
        {
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 0)
            {
                Console.Write("Недопустимое значение.\nВведите число:");
            };
            return choice;
        }
        static public int ExaminationNotZero() // Проверка на ввод верного значения
        {
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice <= 0)
            {
                Console.Write("Недопустимое знаечние для создания массива.\nВведите число:");
            };
            return choice;
        }
        static void Pause()
        {
            Console.WriteLine("\nНажмите любую клавишу, чтобы продолжить.");
            Console.ReadKey(); // Считывание произвольной клавиши
        }
        static public void ConclusionInstructions(int instruction)
        {
            switch (instruction)
            {
            case 1:
                    Console.Write("Введите элемент: ");
                    break;
            case 2:
                    Console.Write("\nВведите количество столбцов: ");
                    Console.Write("\n");
                    break;
            case 3:
                    Console.Write("\nВведите колличество строк: ");
                    Console.Write("\n");
                    break;
            case 4:
                    Console.Write("\nВведите колличество элементов: ");
                    Console.Write("\n");
                    break;
            case 5:
                    Console.WriteLine("\nМассив: \n");
                    break;
            case 6:
                    Console.WriteLine(" Данного выбора нет в представленном списке.");
                    break;
            case 7:
                    Console.WriteLine("Массива не существует или он пуст. :(");
                    break;
            }
        }

    }
}
