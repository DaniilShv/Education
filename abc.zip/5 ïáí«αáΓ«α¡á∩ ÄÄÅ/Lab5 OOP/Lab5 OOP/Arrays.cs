﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Lab5_OOP
{
    internal class Arrays
    {
        static Random random = new Random();
        static public int GetRandom() // Метод для получения рандомного числа от 0 до 100
        {
            return random.Next(0, 100);
        }
        // Одномерный массив
        static public int[] FillingArra(int columns) // Ручное заполняем значениями одномерный массива
        {
            int[] array = new int[columns];
            for (int i = 0; i < columns; i++)
            {
                Menue.ConclusionInstructions(1);
                array[i] = Menue.Examination();
            }
            return array;
        }
        static public int[] RandArray(int columns) // Заполняем произвольными значениями одномерный массива
        {
            int[] array = new int[columns];
            for (int i = 0; i < columns; i++)
            {
                array[i] = GetRandom();
            }
            return array;
        }
        // Двумерный масив
        static public int[,] FillingMultiArray(int row, int columns) // Ручное заполняем значениями многомергного массива
        {
            int[,] multiarray = new int[row, columns];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < columns; j++) 
                {
                    Menue.ConclusionInstructions(1);
                    multiarray[i, j] = Menue.Examination();
                }
            }
            return multiarray;
        }
        static public int[,] RandArrayMulti(int row, int columns) // Создаём многомерный массива
        {
            int[,] multiarray = new int[row, columns];
            for (int i = 0; i < row; i++)
            {
                for(int j = 0; j < columns; j++) { multiarray[i ,j] = GetRandom(); }
            }
            return multiarray;
        }
        // рваный массв
        static public int [][] FillingArrayRagged(int row) // Ручное заполняем значениями рваного массива
        {
            int[][] tornarray = new int[row][];
            for (int i = 0; i < row; i++){
                Menue.ConclusionInstructions(2);
                int columns = Menue.ExaminationNotZero();
                tornarray[i] = new int[columns];

                for (int j = 0; j < columns; j++){
                    Menue.ConclusionInstructions(1);
                    tornarray[i][j] = Menue.Examination();
                }

            }
            if (tornarray.Length == 0)
            {
                Menue.ConclusionInstructions(7);
                return tornarray;
            }
            return tornarray;
        }
        static public int[][] RandArrayRagged(int row) // Создаём рваного массива
        {
            int[][] tornarray = new int[row][];
            for (int i = 0; i < row; i++)
            {
                Menue.ConclusionInstructions(2);
                int columns = Menue.ExaminationNotZero();
                tornarray[i] = new int[columns];

                for (int j = 0; j < columns; j++)
                {
                    tornarray[i][j] = GetRandom();
                }
            }
            if (tornarray.Length == 0)
            {
                Menue.ConclusionInstructions(7);
                return tornarray;
            }
            return tornarray;
        }
        // реализация заданий:
        static public int[] RemoveEven(int[] array) // Удаление первого чётного элемента
        {
            if (array.Length == 0) {
                Menue.ConclusionInstructions(7);
                return array; 
            }
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] % 2 == 0) // Проверка на четность
                {
                    int[] newarray = new int[array.Length - 1]; // Если чётный элемент найден, создаём массив на 1 меньше
                    int newIndex = 0;

                    for (int j = 0; j < i; j++) // Копируем элементы до четного
                    {
                        newarray[newIndex] = array[j];
                        newIndex++;
                    }
                    for (int j = i + 1; j < array.Length; j++) // Копируем элементы после четного
                    {
                        newarray[newIndex] = array[j];
                        newIndex++;
                    }
                    return newarray;
                }
            }
            if (array.Length == 0)
            {
                Menue.ConclusionInstructions(7);
                return array;
            }
            return array; // Возвращаем исходный массив, если четных элементов нет
        }
        static public int[,] AddRow(int[,] array) // Добавить строку с заданным номером
        {
            if (array.Length == 0)
            {
                Menue.ConclusionInstructions(7);
                return array;
            }

            int rows = array.GetLength(0); // считываем длинну строк
            int columns = array.GetLength(1); // столбцов

            int rowindex = CheckingNumbers(rows); // проверка значения

            int[] new_row = new int[columns]; // строка для добавления
            Console.Write("\nДобавление элементов в новую строку:");
            for (int i = 0; i < columns; ++i)
            {
                Console.Write($"\nВведите {i}-тый элемент новой строки:");
                new_row[i]= Menue.Examination();
            }

            int[,] newarray = new int[rows+1, columns];// Создаем новый массив на одну строку больше
            for (int i = 0; i <= rows; ++i)
            {
                if (i == rowindex) // соответствует ли индекс строки с добовляемой
                {
                    for (int j = 0; j < columns; ++j) // Копируем данные
                    {
                        newarray[i, j] = new_row[j];
                    }
                }
                else
                {
                    for (int j = 0; j < columns; ++j) // перенос элементов
                    {
                        if (i < rowindex) // если мы находимся ниже индекса вставки, сдвигаем индекс на 1
                        {
                            newarray[i, j] = array[i, j];
                        }
                        else
                        {
                            newarray[i, j] = array[i - 1, j]; // Сдвигаем индекс для копирования
                        }
                    }
                }
            }
            if (array.Length == 0)
            {
                Menue.ConclusionInstructions(7);
                return array;
            }
            return newarray;
        }
        static public int[][] DellLongestRow(int[][] array)
        {
            if (array.Length == 0)
            {
                Menue.ConclusionInstructions(7);
                return array;
            }

            if (array.Length == 0) return array;
            int rows = array.GetLength(0);
            bool execute = true;
            int max = 0;
            int rowindex = 0;

            for (int i = 0; i < rows; i++) // поиск индекса самой длинной строки
            {
                if (array[i].Length == array[rowindex].Length) // посик равных строк
                {
                    execute = false;
                }
                if (array[i].Length > max)
                {
                    max = array[i].Length;
                    rowindex = i;
                    execute = true;
                }
            }
            if (execute)
            {
                int[][] newarray = new int[rows - 1][];
                for (int i = 0, j = 0; i < rows; i++) // удаление самой длинной строки
                {
                    if (i != rowindex)
                    {
                        newarray[j] = new int[array[i].Length];
                        for (int k = 0; k < array[i].Length; k++)
                        {
                            newarray[j][k] = array[i][k];
                        }
                        j++;
                    }
                }

                return newarray;
            }
            else {  return array; }
            if (array.Length == 0)
            {
                Menue.ConclusionInstructions(7);
                return array;
            }
        }
        static public int CheckingNumbers(int rows)
        {
            Console.Write("Введите номер строки которую хотите добавить:");
            int rowindex = Menue.Examination();
            while (rowindex > rows)
            {
                Console.Write("Неверный номер:");
                rowindex = Menue.Examination();
                rowindex = rowindex - 1;
            };
            if (rowindex == 0 || rowindex != rows) { rowindex = rowindex - 1;} // НОМЕР
            return rowindex;
        }
        //static public bool VoidCheck(int[] array, int[,] multiarray, int[][] tornarray) 
        //{
            //if (array.Length == 0)
            //{
              //  Menue.ConclusionInstructions(7); // "ОШИБКА"
               // return false;
           // }
        //}
    }

}
