﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_OOP
{
    internal class Menu
    {
        public void int MainMaue()
        {
            int choice;
            do
            {
                Console.Write("\nЛабораторныя работа №5, работа с массивами: ");
                univers.Print();
                Console.Write("\n");


                Console.Write("__Выбери действие___\n 1. Одномерный массив\n 2. Двумерный массив\n 3. Рваный массив\n 0. Выход\n Выберите действие: ");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                         // Одномерный
                        break;
                    case 2:
                        // Двумерный
                        break;
                    case 3:
                        // Рваный
                        break;
                        Console.Write("Такого варианта нет в предложенном списке:(");
                        break;
                }
            } while (choice != 0);
        }
        public void int ChoiseArr()
        {

        }
}
