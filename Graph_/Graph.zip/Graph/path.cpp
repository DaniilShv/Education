#include "path.h"
#include "ui_path.h"

path::path(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::path)
{
    ui->setupUi(this);
}

path::~path()
{
    delete ui;
}

int MinElement(QVector<int>&); //нахождение минимального элемента в строке
int MinElementIndex(QVector<int>&); //индекс минимального элемента строки
void fNull(QVector<QVector<int>>&, int, int); //зануляем строку и столбец города, в котором уже были

QVector<QString> solve_task(QVector<QVector<int>> matr) {
    QVector<QString> lines;
    QVector<QVector<int>> help_matr = matr; //всопомгательная таблица, где учитывается, какие города мы проходили
    int k = 0;
    QString str = "";

    for (int i = 0; i < help_matr.size(); ++i) {
        int rem_city = i; //переменная будет запоминать город в котором находимся
        for (int j = 0; j < help_matr[i].size() - 1; ++j) {
            str += QString::number(rem_city + 1); str += " -> ";
            int min_el = MinElement(help_matr[rem_city]);
            k += min_el;
            int min_el_index = MinElementIndex(help_matr[rem_city]);
            fNull(help_matr, rem_city, rem_city);
            rem_city = min_el_index; //заменяем индекс на тот город, в который перешел комивояжер
        }
        str += QString::number(rem_city + 1);
        help_matr = matr; //обновляем таблицу смежности для следующей итерации
        if (k < 100000) {
            lines.push_back(str + " Расстояние: " + QString::number(k));
        }
        str = "";
        k = 0;
    }
    return lines;
}

int MinElement(QVector<int>& arr) {
    int min_el = 100000;
    for (int i = 0; min_el == 0; ++i)
        min_el = arr[i];
    for (auto i = 0; i < arr.size(); ++i) {
        if (arr[i] < min_el && arr[i] != 0)
            min_el = arr[i];
    }
    return min_el;
}
int MinElementIndex(QVector<int>& arr) {
    int min_el = 100000;
    for (int i = 0; min_el == 0; ++i)
        min_el = arr[i];
    int index = 0;
    for (auto i = 0; i < arr.size(); ++i) {
        if (arr[i] < min_el && arr[i] != 0) {
            min_el = arr[i];
            index = i;
        }
    }
    return index;
}
void fNull(QVector<QVector<int>>& a, int cur_column, int cur_str) {
    for (int i = 0; i < a.size(); ++i) {
        a[cur_str][i] = 0;
    }
    for (int i = 0; i < a.size(); ++i) {
        a[i][cur_column] = 0;
    }
}

void path::show_paths(QVector<QVector<int> > matr)
{
    QVector<QString> temp = solve_task(matr);
    QString tmp = "";
    for (int i = 0; i < temp.size(); ++i){
        tmp += temp[i];
        tmp += "\n";
    }
    ui->label->setText(tmp);
}
