#ifndef OBJECTGRAPH_H
#define OBJECTGRAPH_H

#include <QObject>
#include <QGraphicsItem>
#include <QPainter>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>
#include <QCursor>

class ObjectGraph : public QObject, public QGraphicsItem
{
public:
    ObjectGraph();
    void counter(int);
private:
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    QString k;
};

#endif // OBJECTGRAPH_H
