#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QGraphicsScene>
#include<QGraphicsView>
#include<QPainter>
#include<QVector>
#include <QGraphicsLineItem>
#include"objectgraph.h"
#include"lineobject.h"
#include"adjmatr.h"
#include"dialog.h"
#include"dialogtodel.h"
#include"path.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();

public slots:
    void Coords_and_text(int num_city, int num_city2, int dist);
    void delCity(int index);
signals:
    void signal_to_matr(QVector<QVector<int>> matr);
    void signal_to_path(QVector<QVector<int>> matr);
private:
    Ui::MainWindow *ui;
    QGraphicsScene* scene;
    QVector<ObjectGraph*> list;
    QVector<LineObject*> line_list;
    int k = 1;
    QVector<QVector<int>> matr;
    AdjMatr* w;
    Dialog* d;
    DialogToDel* del_win;
    path* win_paths;

    int number = 1;
};
#endif // MAINWINDOW_H
