#include "adjmatr.h"
#include "ui_adjmatr.h"

AdjMatr::AdjMatr(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdjMatr)
{
    ui->setupUi(this);
}

AdjMatr::~AdjMatr()
{
    delete ui;
}

void AdjMatr::show_data_from_matr(QVector<QVector<int> > matr)
{
    ui->tableWidget->setRowCount(matr.size());
    ui->tableWidget->setColumnCount(matr.size());
    for (int i = 0; i < matr.size(); ++i){
        for (int j = 0; j < matr[i].size(); ++j){
            ui->tableWidget->setItem(i, j, new QTableWidgetItem(QString::number(matr[i][j])));
        }
    }
}
