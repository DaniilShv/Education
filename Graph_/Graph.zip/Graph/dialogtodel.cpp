#include "dialogtodel.h"
#include "ui_dialogtodel.h"

DialogToDel::DialogToDel(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogToDel)
{
    ui->setupUi(this);
}

DialogToDel::~DialogToDel()
{
    delete ui;
}

void DialogToDel::on_pushButton_clicked()
{
    emit signal_get_index(ui->lineEdit->text().toInt());
    ui->lineEdit->clear();
    this->close();
}

