#ifndef DIALOGTODEL_H
#define DIALOGTODEL_H

#include <QDialog>

namespace Ui {
class DialogToDel;
}

class DialogToDel : public QDialog
{
    Q_OBJECT

public:
    explicit DialogToDel(QWidget *parent = nullptr);
    ~DialogToDel();

private slots:
    void on_pushButton_clicked();
signals:
    void signal_get_index(int i);
private:
    Ui::DialogToDel *ui;
};

#endif // DIALOGTODEL_H
