#ifndef PATH_H
#define PATH_H

#include <QDialog>
#include<QVector>

namespace Ui {
class path;
}

class path : public QDialog
{
    Q_OBJECT

public:
    explicit path(QWidget *parent = nullptr);
    ~path();
public slots:
    void show_paths(QVector<QVector<int>> matr);
private:
    Ui::path *ui;
};

#endif // PATH_H
