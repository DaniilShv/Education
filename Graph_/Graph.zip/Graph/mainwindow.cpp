#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    w = new AdjMatr;
    d = new Dialog;
    del_win = new DialogToDel;
    win_paths = new path;
    connect(this, &MainWindow::signal_to_matr, w, &AdjMatr::show_data_from_matr);
    connect(d, &Dialog::signal_to_draw_line, this, &MainWindow::Coords_and_text);
    connect(del_win, &DialogToDel::signal_get_index, this, &MainWindow::delCity);
    connect(this, &MainWindow::signal_to_path, win_paths, &path::show_paths);
    scene = new QGraphicsScene;
    ui->graphicsView->setScene(scene);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked() //добавить город
{
    ObjectGraph *item = new ObjectGraph;        // Создаём графический элемент
    item->setPos(10,10);
    item->counter(k);
    k += 1;
    list.push_back(item);
    scene->addItem(item);

    QVector<int> temp_matr;
    for (int i = 0; i < number; ++i){
        temp_matr.push_back(0);
    }
    matr.push_back(temp_matr);
    for (int i = 0; i < matr.size(); ++i){
        for (int j = matr[i].size(); j < number; ++j){
            matr[i].push_back(0);
        }
    }
    number += 1;
}


void MainWindow::on_pushButton_3_clicked() //соединить линией
{
    d->show();
}


void MainWindow::on_pushButton_2_clicked() //удаление
{
    del_win->show();
}


void MainWindow::on_pushButton_5_clicked() //матрица смежности
{
//    matr = {
//              {0,5,6,14,15},
//              {5,0,7,10,6},
//              {6,7,0,8,7},
//              {14,10,8,0,9},
//              {15,6,7,9,0}
//             };
    emit signal_to_matr(matr);
    w->show();
}

void MainWindow::Coords_and_text(int num_city, int num_city2, int dist)
{
    if (dist == 0){
        for (int i = 0; i < line_list.size(); ++i){
            if (line_list[i]->x1 == list[num_city-1]->x()){
                scene->removeItem(line_list[i]);
                line_list.erase(line_list.begin()+i);
                matr[num_city-1][num_city2-1] = 0;
                matr[num_city2-1][num_city-1] = 0;
                return;
            }
        }
    }
    LineObject *line = new LineObject;
    line->setCoords(list[num_city-1]->pos().x(), list[num_city-1]->pos().y(), list[num_city2-1]->pos().x(), list[num_city2-1]->pos().y());
    line->addText(QString::number(dist));
    line_list.push_back(line);
    scene->addItem(line);
    matr[num_city-1][num_city2-1] = dist;
    matr[num_city2-1][num_city-1] = dist;

}

void MainWindow::delCity(int index)
{
    scene->removeItem(list[index-1]);
    matr.erase(matr.begin()+index-1);
    for (int i = 0; i < matr.size(); ++i){
        matr[i].erase(matr[i].begin()+index-1);
    }
    number -= 1;
}


void MainWindow::on_pushButton_6_clicked()
{
    emit signal_to_path(matr);
    win_paths->show();
}

