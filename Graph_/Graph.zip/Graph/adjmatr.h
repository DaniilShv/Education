#ifndef ADJMATR_H
#define ADJMATR_H

#include <QDialog>
#include<QDebug>

namespace Ui {
class AdjMatr;
}

class AdjMatr : public QDialog
{
    Q_OBJECT

public:
    explicit AdjMatr(QWidget *parent = nullptr);
    ~AdjMatr();
public slots:
    void show_data_from_matr(QVector<QVector<int>> matr);
private:
    Ui::AdjMatr *ui;
};

#endif // ADJMATR_H
