#ifndef LINEOBJECT_H
#define LINEOBJECT_H

#include <QObject>
#include <QGraphicsItem>
#include <QPainter>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>
#include <QCursor>

class LineObject: public QObject, public QGraphicsItem
{
public:
    LineObject();
    void setCoords(int ax, int ay, int bx, int by);
    void addText(QString a);
    int x1,x2,y1,y2;
private:
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    QString text;
};

#endif // LINEOBJECT_H
