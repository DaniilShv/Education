#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    emit signal_to_draw_line(ui->firstCity->text().toInt(), ui->secondCity->text().toInt(), ui->LineEditDist->text().toInt());
    ui->firstCity->clear();
    ui->secondCity->clear();
    ui->LineEditDist->clear();
    this->close();
}

