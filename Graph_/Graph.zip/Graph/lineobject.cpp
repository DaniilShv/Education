#include "lineobject.h"

LineObject::LineObject()
{

}

void LineObject::setCoords(int ax, int ay, int bx, int by)
{
    x1 = ax; x2 = bx; y1 = ay; y2 = by;
}

void LineObject::addText(QString a)
{
    this->text = a;
}

QRectF LineObject::boundingRect() const
{
    return QRectF (-30,-30,60,60);
}

void LineObject::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QPen pen; pen.setColor(Qt::black); pen.setWidth(1);
    painter->setPen(pen);
    painter->setRenderHint(QPainter::Antialiasing, true);
    painter->drawLine(x1,y1,x2,y2);
    painter->drawText((x1+x2)/2,(y1+y2)/2, text);
    Q_UNUSED(option);
    Q_UNUSED(widget);
}

void LineObject::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    /* Устанавливаем позицию графического элемента
     * в графической сцене, транслировав координаты
     * курсора внутри графического элемента
     * в координатную систему графической сцены
     * */
    this->setPos(mapToScene(event->pos()));
}

void LineObject::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    /* При нажатии мышью на графический элемент
     * заменяем курсор на руку, которая держит этот элемента
     * */
    this->setCursor(QCursor(Qt::ClosedHandCursor));
    Q_UNUSED(event);
}

void LineObject::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    /* При отпускании мышью элемента
     * заменяем на обычный курсор стрелку
     * */
    this->setCursor(QCursor(Qt::ArrowCursor));
    Q_UNUSED(event);
}

