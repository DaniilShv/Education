/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLineEdit *firstCity;
    QLineEdit *secondCity;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QLineEdit *LineEditDist;
    QLabel *label_3;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(400, 300);
        firstCity = new QLineEdit(Dialog);
        firstCity->setObjectName(QString::fromUtf8("firstCity"));
        firstCity->setGeometry(QRect(120, 70, 113, 21));
        secondCity = new QLineEdit(Dialog);
        secondCity->setObjectName(QString::fromUtf8("secondCity"));
        secondCity->setGeometry(QRect(120, 110, 113, 21));
        label = new QLabel(Dialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 70, 76, 13));
        label_2 = new QLabel(Dialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 110, 73, 13));
        pushButton = new QPushButton(Dialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 250, 80, 21));
        LineEditDist = new QLineEdit(Dialog);
        LineEditDist->setObjectName(QString::fromUtf8("LineEditDist"));
        LineEditDist->setGeometry(QRect(120, 150, 113, 21));
        label_3 = new QLabel(Dialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(50, 150, 62, 16));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", nullptr));
        label->setText(QApplication::translate("Dialog", "\320\237\320\265\321\200\320\262\321\213\320\271 \320\263\320\276\321\200\320\276\320\264:", nullptr));
        label_2->setText(QApplication::translate("Dialog", "\320\222\321\202\320\276\321\200\320\276\320\271 \320\263\320\276\321\200\320\276\320\264:", nullptr));
        pushButton->setText(QApplication::translate("Dialog", "\320\236\320\272", nullptr));
        label_3->setText(QApplication::translate("Dialog", "\320\240\320\260\321\201\321\201\321\202\320\276\321\217\320\275\320\270\320\265:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
