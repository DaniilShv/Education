/********************************************************************************
** Form generated from reading UI file 'adjmatr.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADJMATR_H
#define UI_ADJMATR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_AdjMatr
{
public:
    QGridLayout *gridLayout;
    QTableWidget *tableWidget;

    void setupUi(QDialog *AdjMatr)
    {
        if (AdjMatr->objectName().isEmpty())
            AdjMatr->setObjectName(QString::fromUtf8("AdjMatr"));
        AdjMatr->resize(500, 500);
        gridLayout = new QGridLayout(AdjMatr);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        tableWidget = new QTableWidget(AdjMatr);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        gridLayout->addWidget(tableWidget, 0, 0, 1, 1);


        retranslateUi(AdjMatr);

        QMetaObject::connectSlotsByName(AdjMatr);
    } // setupUi

    void retranslateUi(QDialog *AdjMatr)
    {
        AdjMatr->setWindowTitle(QApplication::translate("AdjMatr", "\320\234\320\260\321\202\321\200\320\270\321\206\320\260 \321\201\320\274\320\265\320\266\320\275\320\276\321\201\321\202\320\270", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdjMatr: public Ui_AdjMatr {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADJMATR_H
