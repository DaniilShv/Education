/********************************************************************************
** Form generated from reading UI file 'dialogtodel.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGTODEL_H
#define UI_DIALOGTODEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogToDel
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButton;

    void setupUi(QDialog *DialogToDel)
    {
        if (DialogToDel->objectName().isEmpty())
            DialogToDel->setObjectName(QString::fromUtf8("DialogToDel"));
        DialogToDel->resize(133, 86);
        gridLayout = new QGridLayout(DialogToDel);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(DialogToDel);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEdit = new QLineEdit(DialogToDel);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout->addWidget(lineEdit, 1, 0, 1, 1);

        pushButton = new QPushButton(DialogToDel);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 2, 0, 1, 1);


        retranslateUi(DialogToDel);

        QMetaObject::connectSlotsByName(DialogToDel);
    } // setupUi

    void retranslateUi(QDialog *DialogToDel)
    {
        DialogToDel->setWindowTitle(QApplication::translate("DialogToDel", "Dialog", nullptr));
        label->setText(QApplication::translate("DialogToDel", "\320\232\320\260\320\272\320\276\320\271 \320\263\320\276\321\200\320\276\320\264 \321\203\320\264\320\260\320\273\320\270\321\202\321\214?", nullptr));
        pushButton->setText(QApplication::translate("DialogToDel", "\320\236\320\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogToDel: public Ui_DialogToDel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGTODEL_H
