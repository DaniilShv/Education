/********************************************************************************
** Form generated from reading UI file 'path.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PATH_H
#define UI_PATH_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_path
{
public:
    QGridLayout *gridLayout;
    QLabel *label;

    void setupUi(QDialog *path)
    {
        if (path->objectName().isEmpty())
            path->setObjectName(QString::fromUtf8("path"));
        path->resize(375, 200);
        gridLayout = new QGridLayout(path);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(path);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(10);
        label->setFont(font);
        label->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        gridLayout->addWidget(label, 0, 0, 1, 1);


        retranslateUi(path);

        QMetaObject::connectSlotsByName(path);
    } // setupUi

    void retranslateUi(QDialog *path)
    {
        path->setWindowTitle(QApplication::translate("path", "Dialog", nullptr));
        label->setText(QApplication::translate("path", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class path: public Ui_path {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PATH_H
