﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestingLib
{
    public class Car : IInit
    {
        static Random rnd = new Random();
        public string Name { get; set; }
        public string Model { get; set; }
        public int ChassisNumber { get; set; }
        string[] carNames = { "BMW", "Mercedes", "Volkswagen", "Ferrari", "Lada", "Audi", "Maseratti", "Skoda", "Porsche" };
        string[] modelNames = { "X5", "3 Series", "5 Series", "Octavia", "Vesta", "Panamera", "Tiguan", "R8", "LaFerrari" };
        public void Init()
        {
            Console.Write("Введите название автомобиля: ");
            Name = Console.ReadLine();
            Console.Write("Введите название модели автомобиля: ");
            Model = Console.ReadLine();
            Console.Write("Введите номер кузова: ");
            int chassisNumber;
            while (!InputInt(out chassisNumber, "Номер кузова(целое число): ")) ;

        }
        public void RandomInit()
        {
            Name = carNames[rnd.Next(carNames.Length)];
            Model = modelNames[rnd.Next(modelNames.Length)];
            ChassisNumber = rnd.Next(1000000, 100000000);
        }
        protected bool InputInt(out int value, string text)
        {
            if (int.TryParse(Console.ReadLine(), out value))
                return true;
            Console.Write(text);
            return false;
        }

        public void ShowInfo()
        {
            Console.WriteLine($"Название автомобиля: {Name}");
            Console.WriteLine($"Модель автомобиля: {Model}");
            Console.WriteLine($"Номер кузова: {ChassisNumber}");
        }
    }
}
