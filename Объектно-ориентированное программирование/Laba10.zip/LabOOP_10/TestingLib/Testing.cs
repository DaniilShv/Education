﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TestingLib
{
    public class Testing : IInit, ICloneable, IComparable<Testing>
    {
        protected static Random rnd = new Random();
        public string SubjectName { get; set; }
        public int[] arr = { 5, 6, 7 };
        public string Task { get; set; }
        protected static string[] subjectNames = { "Алгебра", "Дискретная математика", "Информатика", "Алгоритмизация", "Проектирование" };
        protected string[] taskNames = { "Посчитать", "Решить задание", "Сделать рисунок", "Нарисовать схему" };
        public Testing() { }
        public Testing(string taskName, string subjectName)
        {
            SubjectName = subjectName;
            Task = taskName;
        }
        public virtual void Init()
        {
            Console.Write("Введите название предмета: ");
            SubjectName = Console.ReadLine();
            Console.Write("Введите название задания: ");
            Task = Console.ReadLine();
        }
        public virtual void RandomInit()
        {
            SubjectName = subjectNames[rnd.Next(subjectNames.Length)];
            Task = taskNames[rnd.Next(taskNames.Length)];
        }
        public int CompareTo(Testing testing)
        {
            if (testing is null)
                throw new ArgumentNullException("Объект ссылается на null");
            if (SubjectName.CompareTo(testing.SubjectName) == 0)
            {
                return Task.CompareTo(testing.Task);
            }
            return SubjectName.CompareTo(testing.SubjectName);
        }
        public T ShallowCopy<T>()
        {
            return (T)this.MemberwiseClone();
        }
        public virtual object Clone() => new Testing(Task, SubjectName);
        public virtual void ShowInfo()
        {
            Console.WriteLine($"Название предмета: {SubjectName}");
            Console.WriteLine($"Задание: {Task}");
        }
        protected bool InputInt(out int value, string text)
        {
            if (int.TryParse(Console.ReadLine(), out value))
                return true;
            Console.Write(text);
            return false;
        }
        //public static bool BinarySearch(Testing[] arr, Testing search)
        //{
        //    int left = 0, right = arr.Length - 1, mid = (right + left) / 2;
        //    while (left <= right)
        //    {
        //        if (arr[mid].CompareTo(search) < 0)
        //            left = mid + 1;
        //        else
        //            right = mid - 1;
        //        if (arr[mid].Equals(search))
        //            return true;
        //        mid = (right + left) / 2;
        //    }
        //    return false;
        //}
        public override bool Equals(object obj)
        {
            if (obj is Testing testing)
            {
                return testing.Task == this.Task 
                    && testing.SubjectName == this.SubjectName;
            }
            return false;
        }
        public override string ToString()
        {
            return $"Название предмета: {SubjectName}, Задание: {Task}";
        }
        public void ShowSubjectName()
        {
            Console.WriteLine($"Название предмета: {SubjectName}");
        }
        public void ShowTaskNames()
        {
            Console.WriteLine($"Задание: {Task}");
        }
    }
    public class Test : Testing
    {
        public int CountAnswers { get; set; }
        public Test() { }
        public Test(string taskName, string subjectName, int countAnswers):base(taskName, subjectName)
        {
            CountAnswers = countAnswers;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Количество вариантов ответов: {CountAnswers}");
        }
        public override void Init()
        {
            base.Init();
            int countAnswers;
            Console.Write("Введите количество ответов на тест: ");
            while (!InputInt(out countAnswers, "Введите целое число ответов на тест: "));
            CountAnswers = countAnswers;
        }
        public override void RandomInit()
        {
            base.RandomInit();
            CountAnswers = rnd.Next(3,10);
        }
        public override bool Equals(object obj)
        {
            if (obj is Test testing)
            {
                return testing.Task == this.Task && testing.SubjectName == this.SubjectName
                    && testing.CountAnswers == this.CountAnswers;
            }
            return false;
        }
        public override string ToString()
        {
            return $"Название предмета: {SubjectName}, Задание: {Task}\nКоличество ответов: {CountAnswers}";
        }
        public override object Clone()
        {
            return new Test(Task, SubjectName, CountAnswers);
        }
    }
    public class Exam : Testing
    {
        public int VarNumber { get; set; }
        public Exam() { }
        public Exam(string taskName, string subjectName, int varNumber):base(taskName, subjectName)
        {
            VarNumber = varNumber;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Номер варианта: {VarNumber}");
        }
        public override void Init()
        {
            base.Init();
            int varNumber;
            Console.Write("Введите номер варианта: ");
            while (!InputInt(out varNumber, "Введите номер варианта(целое число): ")) ;
            VarNumber = varNumber;
        }
        public override void RandomInit()
        {
            base.RandomInit();
            VarNumber = rnd.Next(1,25);
        }
        public override bool Equals(object obj)
        {
            if (obj is Exam testing)
            {
                return testing.Task == this.Task && testing.SubjectName == this.SubjectName &&
                    testing.VarNumber == this.VarNumber;
            }
            return false;
        }
        public override string ToString()
        {
            return $"Название предмета: {SubjectName}, Задание: {Task}\nНомер варианта: {VarNumber}";
        }
        public override object Clone()
        {
            return new Exam(Task, SubjectName, VarNumber);
        }
    }
    public class GraduationExam : Exam
    {
        public int IdentifyNumber { get; set; }
        public GraduationExam() { }
        public GraduationExam(string taskName, string subjectName, int varNumber, int identifyNumber)
            : base(taskName, subjectName, varNumber)
        {
            IdentifyNumber = identifyNumber;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Идентификатор: {IdentifyNumber}");
        }
        public override void Init()
        {
            base.Init();
            int identifyNumber;
            Console.Write("Введите идентификатор: ");
            while (!InputInt(out identifyNumber, "Введите идентификатор (целое число): ")) ;
            IdentifyNumber = identifyNumber;
        }
        public override void RandomInit()
        {
            base.RandomInit();
            IdentifyNumber = rnd.Next(1000000, 100000000);
        }
        public override bool Equals(object obj)
        {
            if (obj is GraduationExam testing)
            {
                return testing.Task == this.Task && testing.SubjectName == this.SubjectName &&
                    testing.VarNumber == this.VarNumber && testing.IdentifyNumber == this.IdentifyNumber;
            }
            return false;
        }
        public override string ToString()
        {
            return $"Название предмета: {SubjectName}, Задание: {Task}" +
                $"\nНомер варианта: {VarNumber}, Идентификатор: {IdentifyNumber}";
        }
        public override object Clone()
        {
            return new GraduationExam(Task, SubjectName, VarNumber, IdentifyNumber);
        }
    }
}
