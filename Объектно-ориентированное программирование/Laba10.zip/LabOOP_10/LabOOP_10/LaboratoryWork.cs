﻿using System;
using TestingLib;
using MenuLib;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.CodeDom.Compiler;
using System.Xml.Linq;

namespace LabOOP_10
{
    internal class LaboratoryWork
    {
        Menu menu = new Menu();
        Menu helpMenu = new Menu();
        Testing[] arr = new Testing[0];
        IInit[] arr_iinit = new IInit[0];
        public void Execute()
        {
            menu.AddMenu(AddPointMenu(ExecutePointMenu1, "Создать объект иерархии классов"));
            menu.AddMenu(AddPointMenu(ExecutePointMenu2, "Показать все объекты", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu3, "Заполнить все объекты рандомайзером", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu4, "Заполнять объекты вручную", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu5, "Отсортировать объекты (по названиям предмтов)", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu6, "Показать названия предметов", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu7, "Показать названия заданий", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu8, "Бинарный поиск", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu9, "Инициализировать элемент по номеру", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu10, "Создать клон объекта", 1));
            menu.AddMenu(AddPointMenu(ExecutePointMenu11, "Демонстрация разницы ShallowCopy и Clone"));
            menu.AddMenu(AddPointMenu(ExecutePointMenu12, "Отсортировать объекты (по названиям заданий)"));
            menu.AddMenu(AddPointMenu(ExecutePointMenu13, "Создать объект класса Car"));
            menu.AddMenu(AddPointMenu(ExecutePointMenu14, "Показать все объекты массива IInit"));

            helpMenu.AddMenu(AddPointMenu(AddTesting, "Создать объект класса Testing"));
            helpMenu.AddMenu(AddPointMenu(AddTest, "Создать объект класса Test"));
            helpMenu.AddMenu(AddPointMenu(AddExam, "Создать объект класса Exam"));
            helpMenu.AddMenu(AddPointMenu(AddGraduationExam, "Создать объект класса GraduationExam"));
            menu.Execute();
        }
        PointMenu AddPointMenu(ExecutePointMenu function, string text)
        {
            PointMenu p = new PointMenu();
            p.AddValue(text, function);
            return p;
        }
        PointMenu AddPointMenu(ExecutePointMenu function, string text, int dependence)
        {
            PointMenu p = new PointMenu();
            p.AddValue(text, function, dependence);
            return p;
        }
        void ExecutePointMenu1()
        {
            helpMenu.Execute();
        }
        void ExecutePointMenu2()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(i+1 + ") ");
                arr[i].ShowInfo();
                Console.WriteLine();
            }
        }
        void ExecutePointMenu3() 
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i].RandomInit();
            }
        }
        void ExecutePointMenu4()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i].Init();
                Console.WriteLine();
            }
        }
        void ExecutePointMenu5()
        {
            Array.Sort(arr, new CompareBySubject());
            Console.WriteLine("Элементы отсортированы");
        }
        void ExecutePointMenu6()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{i+1}) ");
                arr[i].ShowSubjectName();
                Console.WriteLine();
            }
        }
        void ExecutePointMenu7()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{i + 1}) ");
                arr[i].ShowTaskNames();
                Console.WriteLine();
            }
        }
        void ExecutePointMenu8()
        {
            Testing search = new Testing();
            search.Init();
            if (Array.BinarySearch(arr, search, new CompareBySubject()) == -1)
                Console.WriteLine("Такого элемента нет в коллекции");
            else
                Console.WriteLine("Такой элемент есть в коллекции");
        }
        void ExecutePointMenu9()
        {
            int value;
            while (!InputInt(out value)) ;
            if (value >= 0 && value <= arr.Length)
                arr[value - 1].Init();
            else
                Console.WriteLine("Введите корректно номер");
        }
        void ExecutePointMenu10()
        {
            int value;
            while (!InputInt(out value)) ;
            Add((Testing)arr[value - 1].Clone());
        }
        void ExecutePointMenu11()
        {
            Console.WriteLine("Для наглядности внутри класса прописан массив (ссылочный тип)");
            Testing test = new Testing();
            Testing test2 = (Testing)test.Clone();
            Testing test3 = test.ShallowCopy<Testing>();
            Console.WriteLine("Изначально массив внутри класса содержит элементы\n" +
                "int[] arr = {5, 6, 7}\n");
            Console.WriteLine(
                "Testing test = new Testing();\n" +
            "Testing test2 = (Testing)test.Clone();\n" +
            "Testing test3 = test.ShallowCopy<Testing>();\n");
            Console.WriteLine(
                "test.arr[0] = 9;\n" +
            "Console.WriteLine(test2.arr[0]);\n" +
            "Console.WriteLine(test3.arr[0]);\n"
            );
            test.arr[0] = 9;
            Console.WriteLine($"Элемент созданный через Clone() указывает на другую область памяти" +
                $"\ntest2.arr[0] = {test2.arr[0]}");
            Console.WriteLine($"Элемент созданный через ShallowCopy() указывает на ту же область памяти" +
                $"\nчто и test, test3.arr[0] = {test3.arr[0]}");
        }
        void ExecutePointMenu12()
        {
            Array.Sort(arr, new CompareByTask());
            Console.WriteLine("Массив отсортирован по название заданий");
        }
        void ExecutePointMenu13()
        {
            Car car = new Car();
            car.RandomInit();
            IInit[] temp_ = new IInit[arr_iinit.Length + 1];
            for (int i = 0; i < arr.Length; i++)
            {
                temp_[i] = arr[i];
            }
            temp_[arr_iinit.Length] = car;
            arr_iinit = temp_;
        }
        void ExecutePointMenu14()
        {
            for (int i = 0; i < arr_iinit.Length; i++)
            {
                arr_iinit[i].ShowInfo();
                Console.WriteLine();
            }
        }
        void AddTesting()
        {
            Testing element = new Testing();
            Add(element);
            Console.WriteLine("Добавлен элемент класса Testing");
        }
        void AddTest()
        {
            Test element = new Test();
            Add(element);
            Console.WriteLine("Добавлен элемент класса Test");
        }
        void AddExam()
        {
            Exam element = new Exam();
            Add(element);
            Console.WriteLine("Добавлен элемент класса Exam");
        }
        void AddGraduationExam()
        {
            GraduationExam element = new GraduationExam();
            Add(element);
            Console.WriteLine("Добавлен элемент класса GraduationExam");
        }
        void ShowMessage()
        {
            Console.WriteLine("Для продолжения нажмите Enter");
            Console.ReadLine();
        }
        void Add(Testing element)
        {
            Testing[] temp = new Testing[arr.Length + 1];
            IInit[] temp_ = new IInit[arr_iinit.Length + 1];
            for (int i = 0; i < arr.Length; i++)
            {
                temp[i] = arr[i];
                temp_[i] = arr[i];
            }
            temp[arr.Length] = element;
            temp_[arr_iinit.Length] = element;
            arr = temp;
            arr_iinit = temp_;
        }
        bool InputInt(out int value)
        {
            Console.Write("Введите номер элемента: ");
            if (int.TryParse(Console.ReadLine(), out value))
                if (value > 0 && value <= arr.Length)
                    return true;
            return false;
        }
    }

}
