﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestingLib;

namespace LabOOP_10
{
    public class CompareByTask : IComparer<Testing>
    {
        public int Compare(Testing x, Testing y)
        {
            if (x.Task.CompareTo(y.Task) < 0)
                return -1;
            if (x.Task.CompareTo(y.Task) == 0)
                return 0;
            return 1;
        }
    }
}
