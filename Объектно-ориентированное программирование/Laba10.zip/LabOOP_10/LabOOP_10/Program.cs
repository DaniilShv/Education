﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using TestingLib;

namespace LabOOP_10
{
    internal class Program
    {
        //рандом ввод, с клавиатуры
        //бинарный поиск, сортировка (с компаратором)
        //создание разных экземпляров класса
        static void Main(string[] args)
        {
            LaboratoryWork lab = new LaboratoryWork();
            lab.Execute();
        }
    }
}
