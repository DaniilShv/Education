using LabOOP_16.Infrastructure.Events;
using LabOOP_16.Infrastructure.Interfaces;
using System.Windows.Forms;
using TestingLibrary;

namespace ReadForm
{
    public partial class ReaderForm : Form
    {
        readonly IFileService<Testing> _service;

        public event LogSender logSender;

        public ReaderForm(IFileService<Testing> service)
        {
            InitializeComponent();
            _service = service;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            List<Testing> data = null;
            try
            {
                if (_service is IFileServiceAsync<Testing> fileService)
                {
                    data = await fileService.GetDataAsync();
                }
                else
                {
                    data = _service.GetData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            foreach (var item in data)
            {
                richTextBox1.AppendText($"[{item.ToString()}]\n");
            }
            logSender?.Invoke(this,
                new LogHandler(_service.Path, "������ �����"));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;

            string filename = openFileDialog1.FileName;

            _service.Path = filename;

            textBox1.Text = filename;
        }
    }
}
