﻿using LabOOP_16.Infrastructure;
using LabOOP_16.Infrastructure.Interfaces;
using TestingLibrary;

namespace LabOOP_16.Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void TestMethod1()
        {
            JsonService service = new JsonService();

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files";

            var obj = new Testing();
            obj.RandomInit();
            List<Testing> list = [obj];
            service.AddData(list);

        }

        [TestMethod]
        public void TestMethod2()
        {
            JsonService service = new JsonService();

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files\tests";

            var obj = new Testing();
            obj.RandomInit();
            List<Testing> list = [obj];
            service.AddData(list);

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files\tests\file.json";
            var data = service.GetData();

        }

        [TestMethod]
        public void TestMethod1_binary()
        {
            BinaryFileService service = new BinaryFileService();

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files";

            var obj = new Testing();
            obj.RandomInit();
            List<Testing> list = [obj];
            service.AddData(list);

        }

        [TestMethod]
        public void TestMethod2_binary()
        {
            BinaryFileService service = new BinaryFileService();

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files\tests";

            var obj = new Testing();
            obj.RandomInit();
            List<Testing> list = [obj];
            service.AddData(list);

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files\tests\file.dat";
            var data = service.GetData();

        }

        [TestMethod]
        public void TestMethod1_xml()
        {
            XmlService service = new XmlService();

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files";

            var obj = new Testing();
            obj.RandomInit();
            List<Testing> list = [obj];
            service.AddData(list);

        }

        [TestMethod]
        public void TestMethod2_xml()
        {
            XmlService service = new XmlService();  

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files\tests";

            var obj = new Testing();
            obj.RandomInit();
            List<Testing> list = [obj];
            service.AddData(list);

            service.Path = @"C:\Users\user\source\repos\LabOOP_16\files\tests\file.xml";
            var data = service.GetData();

        }
    }
}
