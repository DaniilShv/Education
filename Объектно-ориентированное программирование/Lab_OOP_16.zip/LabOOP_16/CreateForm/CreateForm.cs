using LabOOP_16.Infrastructure.Events;
using LabOOP_16.Infrastructure.Interfaces;
using System.Diagnostics.Eventing.Reader;
using TestingLibrary;

namespace CreateForm
{
    public delegate void LogSender(object sender, LogHandler e);
    public partial class CreateForm : Form
    {
        readonly List<Testing> _collection;

        readonly IFileService<Testing> _service;

        public event LogSender logSender;

        public CreateForm(ICollection<Testing> collection,
            IFileService<Testing> service)
        {
            InitializeComponent();
            _collection = new List<Testing>(collection.Count);
            foreach (var item in collection)
            {
                _collection.Add(item);
            }
            _service = service;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (_service is IFileServiceAsync<Testing> fileService)
            {
                await fileService.AddDataAsync(_collection);
            }
            else
            {
                _service.AddData(_collection);
            }
            logSender?.Invoke(this,
                new LogHandler(_service.Path, "������ � ����"));
            MessageBox.Show("������ �������� � ����");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.Cancel)
                return;

            string filename = folderBrowserDialog1.SelectedPath;

            _service.Path = filename;

            textBox1.Text = filename;
        }
    }
}
