﻿namespace LabOOP_16
{
    partial class FileProvider
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            comboBox1 = new ComboBox();
            label1 = new Label();
            richTextBox1 = new RichTextBox();
            textBox1 = new TextBox();
            button3 = new Button();
            textBox2 = new TextBox();
            button4 = new Button();
            textBox3 = new TextBox();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            textBox4 = new TextBox();
            button10 = new Button();
            textBox5 = new TextBox();
            button11 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 416);
            button1.Name = "button1";
            button1.Size = new Size(100, 23);
            button1.TabIndex = 1;
            button1.Text = "Сериализовать";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(118, 416);
            button2.Name = "button2";
            button2.Size = new Size(100, 23);
            button2.TabIndex = 2;
            button2.Text = "Прочитать";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Бинарный файл", "JSON", "XML" });
            comboBox1.Location = new Point(12, 387);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(206, 23);
            comboBox1.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 369);
            label1.Name = "label1";
            label1.Size = new Size(69, 15);
            label1.TabIndex = 4;
            label1.Text = "Тип файла:";
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(326, 12);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.ReadOnly = true;
            richTextBox1.Size = new Size(296, 424);
            richTextBox1.TabIndex = 5;
            richTextBox1.Text = "";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 12);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Введите количество";
            textBox1.Size = new Size(146, 23);
            textBox1.TabIndex = 6;
            // 
            // button3
            // 
            button3.Location = new Point(164, 12);
            button3.Name = "button3";
            button3.Size = new Size(117, 23);
            button3.TabIndex = 7;
            button3.Text = "Добавить";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(12, 41);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Название предмета";
            textBox2.Size = new Size(146, 23);
            textBox2.TabIndex = 8;
            // 
            // button4
            // 
            button4.Location = new Point(164, 41);
            button4.Name = "button4";
            button4.Size = new Size(117, 23);
            button4.TabIndex = 9;
            button4.Text = "Очистить элемент";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(12, 70);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Название предмета";
            textBox3.Size = new Size(146, 23);
            textBox3.TabIndex = 10;
            // 
            // button5
            // 
            button5.Location = new Point(164, 70);
            button5.Name = "button5";
            button5.Size = new Size(117, 23);
            button5.TabIndex = 11;
            button5.Text = "Поиск элемента";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(12, 259);
            button6.Name = "button6";
            button6.Size = new Size(146, 23);
            button6.TabIndex = 12;
            button6.Text = "Прочитать коллекцию";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(12, 288);
            button7.Name = "button7";
            button7.Size = new Size(146, 23);
            button7.TabIndex = 13;
            button7.Text = "Очистить коллекцию";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(12, 317);
            button8.Name = "button8";
            button8.Size = new Size(146, 23);
            button8.TabIndex = 14;
            button8.Text = "Записать коллекцию";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(164, 99);
            button9.Name = "button9";
            button9.Size = new Size(117, 38);
            button9.TabIndex = 15;
            button9.Text = "Фильтровать по подстроке";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(12, 108);
            textBox4.Name = "textBox4";
            textBox4.PlaceholderText = "Введите строку";
            textBox4.Size = new Size(146, 23);
            textBox4.TabIndex = 16;
            // 
            // button10
            // 
            button10.Location = new Point(164, 187);
            button10.Name = "button10";
            button10.Size = new Size(117, 38);
            button10.TabIndex = 17;
            button10.Text = "Группировать по названию";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(12, 152);
            textBox5.Name = "textBox5";
            textBox5.PlaceholderText = "Название предмета";
            textBox5.Size = new Size(146, 23);
            textBox5.TabIndex = 18;
            // 
            // button11
            // 
            button11.Location = new Point(164, 143);
            button11.Name = "button11";
            button11.Size = new Size(117, 38);
            button11.TabIndex = 19;
            button11.Text = "Посчитать количество";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // FileProvider
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(634, 448);
            Controls.Add(button11);
            Controls.Add(textBox5);
            Controls.Add(button10);
            Controls.Add(textBox4);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(textBox3);
            Controls.Add(button4);
            Controls.Add(textBox2);
            Controls.Add(button3);
            Controls.Add(textBox1);
            Controls.Add(richTextBox1);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "FileProvider";
            Text = "File Provider";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private Button button2;
        private ComboBox comboBox1;
        private Label label1;
        private RichTextBox richTextBox1;
        private TextBox textBox1;
        private Button button3;
        private TextBox textBox2;
        private Button button4;
        private TextBox textBox3;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private TextBox textBox4;
        private Button button10;
        private TextBox textBox5;
        private Button button11;
    }
}
