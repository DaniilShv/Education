using BinaryTreeLib;
using LabOOP_16.Infrastructure;
using TestingLibrary;

namespace LabOOP_16
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            ApplicationConfiguration.Initialize();
            Application.Run(new FileProvider(new BinaryTree<Testing>(), 
                new JsonService()));
        }
    }
}