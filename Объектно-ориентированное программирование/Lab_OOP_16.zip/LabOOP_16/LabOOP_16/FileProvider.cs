using LabOOP_16.Infrastructure;
using LabOOP_16.Infrastructure.Events;
using LabOOP_16.Infrastructure.Interfaces;
using ReadForm;
using System.Text;
using TestingLibrary;

namespace LabOOP_16
{
    public partial class FileProvider : Form
    {
        readonly ICollection<Testing> _collection;

        readonly IFileServiceAsync<Testing> _service;

        const string _pathRepository = "repository/repository.json";

        public FileProvider(ICollection<Testing> collection,
            IFileServiceAsync<Testing> service)
        {
            InitializeComponent();
            _collection = collection;
            _service = service;
            _service.Path = _pathRepository;

            var list = _service.GetData();
            if (list != null)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    _collection.Add(list[i]);
                }
                foreach (var item in _collection)
                {
                    richTextBox1.AppendText(item.ToString() + "\n");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateForm.CreateForm form = null;
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    form = new CreateForm.CreateForm(_collection,
                        new BinaryFileService());
                    break;
                case 1:
                    form = new CreateForm.CreateForm(_collection,
                        new JsonService());
                    break;
                case 2:
                    form = new CreateForm.CreateForm(_collection,
                        new XmlService());
                    break;
                default:
                    MessageBox.Show("�������� ��� �����");
                    return;
            }
            form.logSender += LogSender;
            form.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReaderForm form = null;
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    form = new ReaderForm(new BinaryFileService());
                    break;
                case 1:
                    form = new ReaderForm(new JsonService());
                    break;
                case 2:
                    form = new ReaderForm(new XmlService());
                    break;
                default:
                    MessageBox.Show("�������� ��� �����");
                    return;
            }
            form.logSender += LogSender;
            form.ShowDialog();
        }

        void LogSender(object sender, LogHandler e)
        {
            const string path = "Log/Log.txt";
            using (FileStream file = new(path, FileMode.Append))
            {
                var text = $"[{DateTime.Now}] | {e.Type} | {e.Path}\n";

                byte[] bytes = Encoding.Default.GetBytes(text);

                file.Write(bytes, 0, bytes.Length);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox1.Text, out int count))
                MessageBox.Show("������� �����");
            for (int i = 0; i < count; i++)
            {
                Random rnd = new();
                Testing obj = null;
                switch (rnd.Next(4))
                {
                    case 0:
                        obj = new Testing();
                        break;
                    case 1:
                        obj = new Test();
                        break;
                    case 2:
                        obj = new Exam();
                        break;
                    case 3:
                        obj = new GraduationExam();
                        break;
                }
                obj.RandomInit();
                _collection.Add(obj);
            }

            textBox1.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var obj = new Testing(textBox2.Text, "");
            if (_collection.Contains(obj))
            {
                _collection.Remove(obj);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var obj = new Testing(textBox3.Text, "");
            if (_collection.Contains(obj))
            {
                MessageBox.Show("True");
            }
            else
                MessageBox.Show("False");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            foreach (var item in _collection)
            {
                richTextBox1.AppendText($"[{item.ToString()}]\n");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            _collection.Clear();
        }

        private async void button8_Click(object sender, EventArgs e)
        {


            List<Testing> list = new(_collection.Count);
            foreach (var item in _collection)
            {
                list.Add(item);
            }

            _service.Path = _pathRepository;
            await _service.TruncateAddDataAsync(list);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();

            var item = _collection.Where(x => x.SubjectName.Contains(textBox4.Text));

            foreach (var obj in item)
            {
                richTextBox1.AppendText(obj.ToString() + "\n");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();

            var item = _collection.GroupBy(x => new { x.SubjectName });

            foreach (var obj in item)
            {
                richTextBox1.AppendText(obj.Key.ToString() + "\n");
                foreach (var item1 in obj)
                {
                    richTextBox1.AppendText(item1.Task + "\n");
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            var item = _collection.Count(x => x.SubjectName == textBox5.Text);

            MessageBox.Show($"���������� ��������: {item}");
        }
    }
}
