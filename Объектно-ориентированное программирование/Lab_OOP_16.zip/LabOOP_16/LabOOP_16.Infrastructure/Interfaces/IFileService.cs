﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabOOP_16.Infrastructure.Interfaces
{
    public interface IFileService<T>
    {
        List<T> GetData();

        void AddData(List<T> data);

        public string Path { get; set; }
    }
}
