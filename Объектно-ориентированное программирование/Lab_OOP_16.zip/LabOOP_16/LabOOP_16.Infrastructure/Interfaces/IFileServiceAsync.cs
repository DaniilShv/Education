﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabOOP_16.Infrastructure.Interfaces
{
    public interface IFileServiceAsync<T> : IFileService<T>
    {
        Task<List<T>> GetDataAsync();

        Task AddDataAsync(List<T> data);

        Task TruncateAddDataAsync(List<T> data);
    }
}
