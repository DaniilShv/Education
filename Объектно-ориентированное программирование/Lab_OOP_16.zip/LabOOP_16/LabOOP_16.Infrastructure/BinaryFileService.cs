﻿using LabOOP_16.Infrastructure.Interfaces;
using System.Reflection.PortableExecutable;
using TestingLibrary;

namespace LabOOP_16.Infrastructure
{
    public class BinaryFileService : IFileService<Testing>
    {

        public string Path { get; set; }

        public void AddData(List<Testing> data)
        {
            using (BinaryWriter file = new(File.Open(Path + @"\file.dat", FileMode.Append)))
            {
                for (int i = 0; i < data.Count; i++)
                {
                    file.Write(data[i].ToString());
                }
            }
        }

        public List<Testing> GetData()
        {
            List<Testing> data = new();

            var fileinfo = new FileInfo(Path);
            if (fileinfo.Extension != ".dat")
                throw new Exception("Выберите json файл");

            using (BinaryReader file = new(File.Open(Path, FileMode.Open)))
            {
                while (file.PeekChar() > -1)
                {
                    string str = file.ReadString();
                    var strArray = str.Split(',');
                    if (strArray.Length == 2)
                        data.Add(new Testing(strArray[0], strArray[1]));
                    if (strArray.Length == 3)
                        data.Add(new Exam(strArray[0], strArray[1], 
                            int.Parse(strArray[2])));
                    if (strArray.Length == 4)
                        data.Add(new GraduationExam(strArray[0], strArray[1],
                            int.Parse(strArray[2]), int.Parse(strArray[3])));
                }
            }

            return data;
        }
    }
}
