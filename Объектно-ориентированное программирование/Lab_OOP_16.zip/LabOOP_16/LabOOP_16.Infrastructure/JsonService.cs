﻿using LabOOP_16.Infrastructure.Interfaces;
using System.Text.Json;
using TestingLibrary;

namespace LabOOP_16.Infrastructure
{
    public class JsonService : IFileServiceAsync<Testing>
    {
        public string Path { get; set; }

        public void AddData(List<Testing> data)
        {
            using (FileStream file = new(Path + @"\file.json", FileMode.Append))
            {
                JsonSerializer.Serialize<List<Testing>>(file, data);
            }
        }

        public async Task AddDataAsync(List<Testing> data)
        {
            using (FileStream file = new(Path + @"\file.json", FileMode.Append))
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };
                await JsonSerializer.SerializeAsync<List<Testing>>(file, data, options);
            }
        }

        public List<Testing> GetData()
        {
            List<Testing> items;

            var file = new FileInfo(Path);
            if (file.Extension != ".json")
                throw new Exception("Выберите json файл");

            using (StreamReader r = new StreamReader(Path))
            {
                string json = r.ReadToEnd();
                if (json == "")
                {
                    return null;
                }
                items = JsonSerializer.Deserialize<List<Testing>>(json);
            }

            return items;
        }

        public async Task<List<Testing>> GetDataAsync()
        {
            List<Testing> items;

            var file = new FileInfo(Path);
            if (file.Extension != ".json")
                throw new Exception("Выберите json файл");

            using (StreamReader r = new StreamReader(Path))
            {
                string json = await r.ReadToEndAsync();
                items = JsonSerializer.Deserialize<List<Testing>>(json);
            }

            return items;
        }

        public async Task TruncateAddDataAsync(List<Testing> data)
        {
            using (FileStream file = new(Path, FileMode.Truncate))
            {
                await JsonSerializer.SerializeAsync<List<Testing>>(file, data);
            }
        }
    }
}
