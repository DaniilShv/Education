﻿using LabOOP_16.Infrastructure.Interfaces;
using System.Xml.Serialization;
using TestingLibrary;

namespace LabOOP_16.Infrastructure
{
    public class XmlService : IFileService<Testing>
    {

        public string Path { get; set; }

        public void AddData(List<Testing> data)
        {
            XmlSerializer serializer = new(typeof(List<Testing>));

            using (FileStream file = new(Path + @"\file.xml", FileMode.Append))
            {
                 serializer.Serialize(file, data);
            }
        }

        public List<Testing> GetData()
        {
            List<Testing> items = new();

            var fileinfo = new FileInfo(Path);
            if (fileinfo.Extension != ".xml")
                throw new Exception("Выберите xml файл");

            XmlSerializer serializer = new(typeof(List<Testing>));

            using (FileStream file = new(Path, FileMode.Open))
            {
                items = serializer.Deserialize(file) as List<Testing>;
            }

            return items;
        }
    }
}
