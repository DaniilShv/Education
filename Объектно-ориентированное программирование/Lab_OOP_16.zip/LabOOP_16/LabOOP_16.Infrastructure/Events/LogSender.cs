﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabOOP_16.Infrastructure.Events
{
    public delegate void LogSender(object sender, LogHandler e);
}
