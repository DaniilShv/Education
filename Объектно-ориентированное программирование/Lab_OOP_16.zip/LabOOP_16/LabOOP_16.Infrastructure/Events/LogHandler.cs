﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabOOP_16.Infrastructure.Events
{
    public class LogHandler : EventArgs
    {
        public string Path { get; set; }
        public string Type { get; set; }
        public LogHandler(string path, string type)
        {
            Path = path;
            Type = type;
        }
    }
}
