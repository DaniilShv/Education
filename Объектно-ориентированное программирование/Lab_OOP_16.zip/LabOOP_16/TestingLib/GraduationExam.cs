﻿using System;

namespace TestingLibrary
{
    public class GraduationExam : Exam
    {
        public int IdentifyNumber { get; set; }
        public GraduationExam() { }
        public GraduationExam(string taskName, string subjectName, int varNumber, int identifyNumber)
            : base(taskName, subjectName, varNumber)
        {
            IdentifyNumber = identifyNumber;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Идентификатор: {IdentifyNumber}");
        }
        public override void RandomInit()
        {
            base.RandomInit();
            IdentifyNumber = rnd.Next(1000000000);
        }

        public override string ToString()
        {
            return base.ToString() + $",{IdentifyNumber}";
        }
    }
}
