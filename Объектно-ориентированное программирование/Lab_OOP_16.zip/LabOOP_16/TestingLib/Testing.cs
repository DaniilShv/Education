﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace TestingLibrary
{
    public class Testing : IInit, IComparable<Testing>, ICloneable, IComparer<Testing>,
        IComparable, IComparer
    {
        static protected Random rnd = new Random();
        public string SubjectName { get; set; }
        public string Task { get; set; }

        protected string[] subjectNames = { "Алгебра", "Дискретная математика", "Информатика", "Алгоритмизация", "Проектирование", "Программирование" };
        protected string[] taskNames = { "Посчитать", "Решить задание", "Сделать рисунок", "Нарисовать схему", "Лабораторная работа" };
        public Testing() { }
        public Testing(string subjectName, string taskName)
        {
            SubjectName = subjectName;
            Task = taskName;
        }
        public void Init()
        {
            Console.Write("Введите название предмета: ");
            SubjectName = Console.ReadLine();
            Console.Write("Введите название задания: ");
            Task = Console.ReadLine();
        }
        public virtual void RandomInit()
        {
            SubjectName = subjectNames[rnd.Next(subjectNames.Length)];
            Task = taskNames[rnd.Next(taskNames.Length)];
        }
        public int CompareTo(Testing test)
        {
            if (SubjectName.CompareTo(test.SubjectName) == 0)
                return Task.CompareTo(test.Task);
            return SubjectName.CompareTo(test.SubjectName);
        }
        public T ShallowCopy<T>()
        {
            return (T)this.MemberwiseClone();
        }
        public object Clone() => new Testing(Task, SubjectName);
        public virtual void ShowInfo()
        {
            Console.WriteLine($"Название предмета: {SubjectName}");
            Console.WriteLine($"Задание: {Task}");
        }
        public override bool Equals(object obj)
        {
            if (obj is Testing testing)
                return SubjectName == testing.SubjectName;
            return false;
        }

        public override string ToString()
        {
            return $"{SubjectName},{Task}";
        }

        public int Compare(Testing x, Testing y)
        {
            if (x.SubjectName.CompareTo(y.SubjectName) == 0)
                return x.Task.CompareTo(y.Task);
            return x.SubjectName.CompareTo(y.SubjectName);
        }

        public int CompareTo(object obj)
        {
            return CompareTo((Testing)obj);
        }

        public int Compare(object x, object y)
        {
            return Compare((Testing)x, (Testing)y);
        }
    }
}
