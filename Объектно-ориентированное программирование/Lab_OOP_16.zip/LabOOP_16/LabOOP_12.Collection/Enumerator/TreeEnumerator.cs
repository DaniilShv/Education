﻿using BinaryTreeLib;
using NodeTree;
using System.Collections;

namespace LabOOP_12.Collection.Enumerator
{
    public class TreeEnumerator<T> : IEnumerator<T> where T : IComparable<T>
    {

        private Queue<T> _treeElements = new Queue<T>();

        private T _current;

        public TreeEnumerator(BinaryTree<T> tree)
        {
            if (tree.Count != 0)
                CreateEnumarator(tree.Head);
        }

        public T Current => _current;

        object IEnumerator.Current => Current;

        public void Dispose()
        {

        }
        public bool MoveNext()
        {
            if (_treeElements.Count == 0)
                return false;
            _current = _treeElements.Dequeue();
            return true;
        }

        public void Reset()
        {

        }

        void CreateEnumarator(NodeTree<T> node)
        {
            if (node.left_ptr == null)
            {
                _treeElements.Enqueue(node.data);
                if (node.right_ptr != null)
                    CreateEnumarator(node.right_ptr);
                return;
            }
            CreateEnumarator(node.left_ptr);
            _treeElements.Enqueue(node.data);
            if (node.right_ptr != null)
                CreateEnumarator(node.right_ptr);
        }
    }
}
