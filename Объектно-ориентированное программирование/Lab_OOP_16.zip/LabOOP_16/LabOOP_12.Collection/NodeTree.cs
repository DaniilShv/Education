﻿namespace NodeTree
{
    public class NodeTree<T>
    {
        public T data;

        public NodeTree<T> left_ptr = null;

        public NodeTree<T> right_ptr = null;
    }
}
