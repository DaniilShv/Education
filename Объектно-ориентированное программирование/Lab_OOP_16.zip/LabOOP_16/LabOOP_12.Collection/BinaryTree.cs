﻿using System.Collections;
using LabOOP_12.Collection.Comparer;
using LabOOP_12.Collection.Enumerator;
using NodeTree;

namespace BinaryTreeLib
{
    public class BinaryTree<T> : ICollection<T> , ICloneable where T: IComparable<T>
    {
        private NodeTree<T> head = null;

        private IComparer<T> _comparer;

        private int _count = 0;

        public BinaryTree(IComparer<T> comparer) => _comparer = comparer;

        public NodeTree<T> Head => head;

        public int Count => _count;

        public bool IsReadOnly { get; set; }

        public BinaryTree() => _comparer = new BaseTreeComparer<T>();

        public BinaryTree(BinaryTree<T> copyTree)
        {
            _comparer = copyTree._comparer;
            Copy(copyTree);
        }

        public void Copy(BinaryTree<T> copyTree)
        {
            Copy(copyTree.Head);
        }

        private void Copy(NodeTree<T> node)
        {
            if (node.left_ptr == null)
            {
                Add(node.data);
                if (node.right_ptr != null)
                    Copy( node.right_ptr);
                return;
            }
            Copy(node.left_ptr);
            Add(node.data);
            if (node.right_ptr != null)
                Copy(node.right_ptr);
        }

        public IEnumerator<T> GetEnumerator() => new TreeEnumerator<T>(this);

        public IEnumerable<T> GetEnumerable()
        {
            return GetEnumerable(head);
        }

        IEnumerable<T> GetEnumerable(NodeTree<T> node)
        {
            if (node != null)
            {
                foreach (var item in GetEnumerable(node.left_ptr))
                {
                    yield return item;
                }
                yield return node.data;
                foreach (var item in GetEnumerable(node.right_ptr))
                {
                    yield return item;
                }
            }
        }

        public void Add(T data)
        {
            if (IsReadOnly)
                throw new InvalidOperationException("Дерево доступно только для чтения");

            if (head == null)
            {
                head = new NodeTree<T> { data = data };
                _count++;
                return;
            }

            NodeTree<T> current = head;
            NodeTree<T> parent = null;  

            while (current != null)
            {
                parent = current;
                if (_comparer.Compare(data, current.data) <= 0)
                {
                    current = current.left_ptr;  
                }
                else
                {
                    current = current.right_ptr; 
                }
            }

            var newNode = new NodeTree<T> { data = data };

            if (_comparer.Compare(data, parent.data) <= 0)
            {
                parent.left_ptr = newNode;
            }
            else
            {
                parent.right_ptr = newNode; 
            }

            _count++;  
        }

        public bool Remove(T data)
        {
            if (IsReadOnly)
                throw new Exception("Tree is read only");
            if (!Contains(data))
                return false;
            Remove(head, data);
            _count--;
            return true;
        }

        private NodeTree<T> Remove(NodeTree<T> node, T data)
        {
            if (node.data.Equals(data))
            {
                if (node.right_ptr == null && node.left_ptr == null)
                {
                    if (node == head)
                    {
                        head = null;
                        return head;
                    }
                    return null;
                }

                else if (node.right_ptr != null && node.left_ptr != null)
                {
                    var maxLeft = GetMax(node.left_ptr);
                    T temp = maxLeft.data;
                    node.left_ptr = Remove(node.left_ptr, temp);
                    node.data = temp;
                    return node;
                }

                else if (node.right_ptr != null || node.left_ptr != null)
                {
                    if (node == head)
                    {
                        head = node.left_ptr != null ? node.left_ptr : node.right_ptr;
                        node = null;
                        return head;
                    }
                    if (node.right_ptr != null)
                    {
                        return node.right_ptr;
                    }
                    if (node.left_ptr != null)
                    {
                        return node.left_ptr;
                    }
                }
            }
            if (_comparer.Compare(node.data, data) < 0)
                node.right_ptr = Remove(node.right_ptr, data);

            if(_comparer.Compare(node.data, data) > 0)
                node.left_ptr = Remove(node.left_ptr, data);

            return node;
        }

        private NodeTree<T> GetMax (NodeTree<T> node)
        {
            NodeTree<T> temp = node;
            while (temp.right_ptr != null)
            {
                temp = temp.right_ptr;
            }
            return temp;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void Clear()
        {
            if (IsReadOnly)
                throw new Exception("Tree is read only");
            if (Count == 0)
                return;
            Clear(head);
            head = null;
            _count = 0;
        }

        NodeTree<T> Clear(NodeTree<T> node)
        {
            if (node.left_ptr == null)
            {
                if (node.right_ptr != null)
                    node.right_ptr = Clear(node.right_ptr);
                return null;
            }
            node.left_ptr = Clear(node.left_ptr);

            if (node.right_ptr != null)
                node.right_ptr = Clear(node.right_ptr);
            return null;
        }

        public bool Contains(T item)
        {
            return Contains(item, head);
        }

        private bool Contains(T item, NodeTree<T> node)
        {
            if (node == null)
                return false;
            if (item.Equals(node.data))
                return true;
            if (_comparer.Compare(item, node.data) < 0)
                return Contains(item, node.left_ptr);
            else
                return Contains(item, node.right_ptr);
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            for (int i = arrayIndex; i < array.Length; i++)
            {
                Add(array[i]);
            }
        }

        public object Clone() => new BinaryTree<T>(this);

        public BinaryTree<T> ShallowCopy() => (BinaryTree<T>)MemberwiseClone();

        public override bool Equals(object? obj)
        {
            if (obj is BinaryTree<T> tree)
            {
                var treeEnum = GetEnumerator();
                var treeEnum_ = tree.GetEnumerator();
                bool res = false;
                while (treeEnum.MoveNext() && treeEnum_.MoveNext() && !res)
                    res = treeEnum.Current.Equals(treeEnum_.Current);
                return res;
            }
            return false;
        }
    }
}
