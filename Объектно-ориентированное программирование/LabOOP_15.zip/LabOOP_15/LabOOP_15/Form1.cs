namespace LabOOP_15
{
    public partial class Form1 : Form
    {
        int _x;

        double _y;

        bool _isStarted = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_isStarted)
                return;

            _x = 0;
            _y = 200;

            switch (comboBox1.SelectedIndex)
            {
                case 1:
                    Task.Run(Calculate);
                    break;
                case 2:
                    Task.Run(CalculateSin);
                    break;
                case 3:
                    Task.Run(CalculateCos);
                    break;
                default:
                    return;
            }
            _isStarted = true;
            Task.Run(MoveButton);
        }

        private void CalculateSin()
        {
            while (_isStarted)
            {
                Task.Delay(20).Wait();
                _x += 1;
                _y = 100 * Math.Sin(_x / 2) + 200;
                if (_x == this.Width)
                {
                    _x = 0;
                    _y = 200;
                }
            }
        }

        private void CalculateCos()
        {
            while (_isStarted)
            {
                Task.Delay(20).Wait();
                _x += 1;
                _y = 100 * Math.Cos(_x / 2) + 200;
                if (_x == this.Width)
                {
                    _x = 0;
                    _y = 200;
                }
            }
        }

        private void Calculate()
        {
            while (_isStarted)
            {
                Task.Delay(20).Wait();
                _x += 10;
                if (_x == this.Width)
                {
                    _x = 0;
                    _y = 200;
                }
            }
        }

        private void MoveButton()
        {
            while (_isStarted)
            {
                button2.Location = new Point(_x, (int)_y);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            _isStarted = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            
        }
    }
}
