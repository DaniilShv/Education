﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using TestingLib;

namespace LabOOP_11
{
    internal class LaboratoryWork
    {
        Stopwatch sw = new Stopwatch();
        static TestCollections testCollections = new TestCollections(1000);
        Test firstTest = new Test(testCollections.listTest.First().Task,
                testCollections.listTest.First().SubjectName,
                testCollections.listTest.First().CountAnswers);
        Test finalTest = new Test(testCollections.listTest.Last().Task,
            testCollections.listTest.Last().SubjectName,
            testCollections.listTest.Last().CountAnswers);
        Test centerTest = new Test(testCollections.listTest[500].Task,
            testCollections.listTest[500].SubjectName,
            testCollections.listTest[500].CountAnswers);
        Test unknownTest = new Test("Нарисовать", "Астрономия", 10);
        public void Execute()
        {
            Console.WriteLine("List<Test>:");
            TestFirstCollection(ref firstTest, ref finalTest, ref centerTest, ref unknownTest);

            Console.WriteLine("\nList<string>:");
            TestFirstCollectionString(ref firstTest, ref finalTest, ref centerTest, ref unknownTest);

            Console.WriteLine("\n(ContainsValue) SortedDictionary<Testing, Test>:");
            TestSecondCollectionValue(ref firstTest, ref finalTest, ref centerTest, ref unknownTest);

            Console.WriteLine("\n(ContainsKey) SortedDictionary<Testing, Test>:");
            TestSecondCollectionKey(ref firstTest, ref finalTest, ref centerTest, ref unknownTest);

            Console.WriteLine("\n(ContainsValue) SortedDictionary<string, Test>: ");
            TestSecondCollectionStringValue(ref firstTest, ref finalTest, ref centerTest, ref unknownTest);

            Console.WriteLine("\n(ContainsKey) SortedDictionary<string, Test>: ");
            TestSecondCollectionStringKey(ref firstTest, ref finalTest, ref centerTest, ref unknownTest);

            Console.WriteLine();
        }
        void TestFirstCollection(ref Test firstTest, ref Test finalTest, ref Test centerTest, ref Test unknownTest)
        {
            long valueFirstTest = 0, valueFinalTest = 0, valueUnknownTest = 0, valueCenterTest = 0;
            for (int i = 0; i < 5; ++i)
            {
                sw.Start();
                if (testCollections.listTest.Contains(firstTest))
                {
                    sw.Stop();
                    valueFirstTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.listTest.Contains(finalTest))
                {
                    sw.Stop();
                    valueFinalTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.listTest.Contains(centerTest))
                {
                    sw.Stop();
                    valueCenterTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (!testCollections.listTest.Contains(unknownTest))
                {
                    sw.Stop();
                    valueUnknownTest += sw.ElapsedTicks;
                }
                sw.Reset();
            }
            Console.WriteLine($"Время нахождения первого элемента: {valueFirstTest / 5}");
            Console.WriteLine($"Время нахождения центрального элемента: {valueCenterTest / 5}");
            Console.WriteLine($"Время нахождения последнего элемента: {valueFinalTest / 5}");
            Console.WriteLine($"Время нахождения неизвестного элемента: {valueUnknownTest / 5}");
        }
        void TestFirstCollectionString(ref Test firstTest, ref Test finalTest, ref Test centerTest, ref Test unknownTest)
        {
            long valueFirstTest = 0, valueFinalTest = 0, valueUnknownTest = 0, valueCenterTest = 0;
            for (int i = 0; i < 5; i++)
            {
                sw.Start();
                if (testCollections.listString.Contains(firstTest.ToString()))
                {
                    sw.Stop();
                    valueFirstTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.listString.Contains(finalTest.ToString()))
                {
                    sw.Stop();
                    valueFinalTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.listString.Contains(centerTest.ToString()))
                {
                    sw.Stop();
                    valueCenterTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (!testCollections.listString.Contains(unknownTest.ToString()))
                {
                    sw.Stop();
                    valueUnknownTest += sw.ElapsedTicks;
                }
                sw.Reset();
            }
            Console.WriteLine($"Время нахождения первого элемента: {valueFirstTest / 5}");
            Console.WriteLine($"Время нахождения центрального элемента: {valueCenterTest / 5}");
            Console.WriteLine($"Время нахождения последнего элемента: {valueFinalTest / 5}");
            Console.WriteLine($"Время нахождения неизвестного элемента: {valueUnknownTest / 5}");
        }
        void TestSecondCollectionValue(ref Test firstTest, ref Test finalTest, ref Test centerTest, ref Test unknownTest)
        {
            long valueFirstTest = 0, valueFinalTest = 0, valueUnknownTest = 0, valueCenterTest = 0;
            for (int i = 0; i < 5; i++)
            {
                sw.Start();
                if (testCollections.dictTesting.ContainsValue(firstTest))
                {
                    sw.Stop();
                    valueFirstTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictTesting.ContainsValue(finalTest))
                {
                    sw.Stop();
                    valueFinalTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictTesting.ContainsValue(centerTest))
                {
                    sw.Stop();
                    valueCenterTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (!testCollections.dictTesting.ContainsValue(unknownTest))
                {
                    sw.Stop();
                    valueUnknownTest += sw.ElapsedTicks;
                }
                sw.Reset();
            }
            Console.WriteLine($"Время нахождения первого элемента: {valueFirstTest / 5}");
            Console.WriteLine($"Время нахождения центрального элемента: {valueCenterTest / 5}");
            Console.WriteLine($"Время нахождения последнего элемента: {valueFinalTest / 5}");
            Console.WriteLine($"Время нахождения неизвестного элемента: {valueUnknownTest / 5}");
        }
        void TestSecondCollectionKey(ref Test firstTest, ref Test finalTest, ref Test centerTest, ref Test unknownTest)
        {
            long valueFirstTest = 0, valueFinalTest = 0, valueUnknownTest = 0, valueCenterTest = 0;
            for (int i = 0; i < 5; i++)
            {
                sw.Start();
                if (testCollections.dictTesting.ContainsKey(firstTest))
                {
                    sw.Stop();
                    valueFirstTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictTesting.ContainsKey(finalTest))
                {
                    sw.Stop();
                    valueFinalTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictTesting.ContainsKey(centerTest))
                {
                    sw.Stop();
                    valueCenterTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (!testCollections.dictTesting.ContainsKey(unknownTest))
                {
                    sw.Stop();
                    valueUnknownTest += sw.ElapsedTicks;
                }
                sw.Reset();
            }
            Console.WriteLine($"Время нахождения первого элемента: {valueFirstTest / 5}");
            Console.WriteLine($"Время нахождения центрального элемента: {valueCenterTest / 5}");
            Console.WriteLine($"Время нахождения последнего элемента: {valueFinalTest / 5}");
            Console.WriteLine($"Время нахождения неизвестного элемента: {valueUnknownTest / 5}");
        }
        void TestSecondCollectionStringValue(ref Test firstTest, ref Test finalTest, ref Test centerTest, ref Test unknownTest)
        {
            long valueFirstTest = 0, valueFinalTest = 0, valueUnknownTest = 0, valueCenterTest = 0;
            for (int i = 0; i < 5; i++)
            {
                sw.Start();
                if (testCollections.dictString.ContainsValue(firstTest))
                {
                    sw.Stop();
                    valueFirstTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictString.ContainsValue(finalTest))
                {
                    sw.Stop();
                    valueFinalTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictString.ContainsValue(centerTest))
                {
                    sw.Stop();
                    valueCenterTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (!testCollections.dictString.ContainsValue(unknownTest))
                {
                    sw.Stop();
                    valueUnknownTest += sw.ElapsedTicks;
                }
                sw.Reset();
            }
            Console.WriteLine($"Время нахождения первого элемента: {valueFirstTest / 5}");
            Console.WriteLine($"Время нахождения центрального элемента: {valueCenterTest / 5}");
            Console.WriteLine($"Время нахождения последнего элемента: {valueFinalTest / 5}");
            Console.WriteLine($"Время нахождения неизвестного элемента: {valueUnknownTest / 5}");
        }
        void TestSecondCollectionStringKey(ref Test firstTest, ref Test finalTest, ref Test centerTest, ref Test unknownTest)
        {
            long valueFirstTest = 0, valueFinalTest = 0, valueUnknownTest = 0, valueCenterTest = 0;
            for (int i = 0; i < 5; i++)
            {
                sw.Start();
                if (testCollections.dictString.ContainsKey(firstTest.ToString()))
                {
                    sw.Stop();
                    valueFirstTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictString.ContainsKey(finalTest.ToString()))
                {
                    sw.Stop();
                    valueFinalTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (testCollections.dictString.ContainsKey(centerTest.ToString()))
                {
                    sw.Stop();
                    valueCenterTest += sw.ElapsedTicks;
                }
                sw.Reset();

                sw.Start();
                if (!testCollections.dictString.ContainsKey(unknownTest.ToString()))
                {
                    sw.Stop();
                    valueUnknownTest += sw.ElapsedTicks;
                }
                sw.Reset();
            }
            Console.WriteLine($"Время нахождения первого элемента: {valueFirstTest / 5}");
            Console.WriteLine($"Время нахождения центрального элемента: {valueCenterTest / 5}");
            Console.WriteLine($"Время нахождения последнего элемента: {valueFinalTest / 5}");
            Console.WriteLine($"Время нахождения неизвестного элемента: {valueUnknownTest / 5}");
        }
    }
}
