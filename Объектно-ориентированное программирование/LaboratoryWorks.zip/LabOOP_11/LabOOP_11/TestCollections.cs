﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestingLib;

namespace LabOOP_11
{
    internal class TestCollections
    {
        public List<Test> listTest = new List<Test>();
        public List<string> listString = new List<string>();
        public SortedDictionary<Testing, Test> dictTesting = new SortedDictionary<Testing, Test>();
        public SortedDictionary<string, Test> dictString = new SortedDictionary<string, Test>();
        public TestCollections() { }
        public TestCollections(int count)
        {
            InitList(count);
        }
        void InitList(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Test test = new Test();
                test.RandomInit();
                try
                {
                    dictTesting.Add(test.BaseTesting, test);
                    dictString.Add(test.ToString(), test);
                    listTest.Add(test);
                    listString.Add(test.ToString());
                }
                catch (Exception)
                {
                    i--;
                }
            }
        }
    }
}
