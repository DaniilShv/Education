﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestingLib;
using System;
using System.Threading.Tasks;

namespace LaboratoryWorkTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestingConstructor_Test()
        {
            Testing a = new Testing("Посчитать", "Математика");
            Testing b = new Testing();
            b.Task = "Посчитать"; b.SubjectName = "Математика";
            Assert.AreEqual(a, b);
        }
        [TestMethod]
        public void TestConstructor_Test()
        {
            Test a = new Test("Посчитать", "Математика", 10);
            Test b = new Test();
            b.Task = "Посчитать"; b.SubjectName = "Математика"; b.CountAnswers = 10;
            Assert.AreEqual(a, b);
        }
        [TestMethod]
        public void ExamConstructor_Test()
        {
            Exam a = new Exam("Посчитать", "Математика", 10);
            Exam b = new Exam();
            b.Task = "Посчитать"; b.SubjectName = "Математика"; b.VarNumber = 10;
            Assert.AreEqual(a, b);
        }
        [TestMethod]
        public void GraduationExamConstructor_Test()
        {
            GraduationExam a = new GraduationExam("Посчитать", "Математика", 10, 5797846);
            GraduationExam b = new GraduationExam();
            b.Task = "Посчитать"; b.SubjectName = "Математика"; b.VarNumber = 10;
            b.IdentifyNumber = 5797846;
            Assert.AreEqual(a, b);
        }
        [TestMethod]
        public void CompareTo_Test1()
        {
            Testing a = new Testing("Посчитать", "Математика");
            Testing b = new Testing("Посчитать", "Математика");
            Assert.AreEqual(0, a.CompareTo(b));
        }
        [TestMethod]
        public void CompareTo_Test2()
        {
            Testing a = new Testing("Посчитать", "Алгоритмизация");
            Testing b = new Testing("Посчитать", "Математика");
            Assert.AreEqual(-1, a.CompareTo(b));
        }
        [TestMethod]
        public void CompareTo_Test3()
        {
            Testing a = new Testing("Посчитать", "Математика");
            Testing b = new Testing("Посчитать", "Алгоритмизация");
            Assert.AreEqual(1, a.CompareTo(b));
        }
        [TestMethod]
        public void CompareTo_Test4()
        {
            Testing a = new Testing("Посчитать", "Алгоритмизация");
            Testing b = new Testing("Сделать рисунок", "Алгоритмизация");
            Assert.AreEqual(-1, a.CompareTo(b));
        }
        [TestMethod]
        public void CompareTo_Test5()
        {
            Assert.ThrowsException<ArgumentNullException>(FunctionCompareTo_Test5);
        }
        public void FunctionCompareTo_Test5()
        {
            Testing a = new Testing("Посчитать", "Алгоритмизация");
            Testing b = null;
            a.CompareTo(b);
        }
        [TestMethod]
        public void Clone_Test()
        {
            Testing testing = new Testing();
            Testing clone = (Testing)testing.Clone();
            Assert.AreEqual(testing,clone);
        }
        [TestMethod]
        public void ShallowCopy_Test()
        {
            Testing testing = new Testing();
            Testing clone = testing.ShallowCopy<Testing>();
            Assert.AreEqual(testing, clone);
        }
        [TestMethod]
        public void Equals_Test()
        {
            Testing a = new Testing("Решить задачку", "Математика");
            Testing b = new Testing("Сделать рисунок", "Алгоритмизация");
            Assert.AreEqual(false, a.Equals(b));
        }
        [TestMethod]
        public void ToString_TestingClass()
        {
            Testing a = new Testing("a", "b");
            Assert.AreEqual($"Название предмета: {a.SubjectName}, Задание: {a.Task}", a.ToString());
        }
        [TestMethod]
        public void ToString_TestClass()
        {
            Test a = new Test("а", "б", 5);
            Assert.AreEqual($"Название предмета: {a.SubjectName}, Задание: {a.Task}\nКоличество ответов: {a.CountAnswers}", 
                a.ToString());
        }
        [TestMethod]
        public void ToString_ExamClass()
        {
            Exam a = new Exam("a", "b", 5);
            Assert.AreEqual($"Название предмета: {a.SubjectName}, Задание: {a.Task}\nНомер варианта: {a.VarNumber}",
                a.ToString());
        }
        [TestMethod]
        public void ToString_GraduationExamClass()
        {
            GraduationExam a = new GraduationExam("a", "a", 5, 5);
            Assert.AreEqual($"Название предмета: {a.SubjectName}, Задание: {a.Task}" +
                $"\nНомер варианта: {a.VarNumber}, Идентификатор: {a.IdentifyNumber}", a.ToString());
        }
        [TestMethod]
        public void Test_Compare()
        {
            Testing a = new Testing("a", "b");
            Testing b = new Testing("b", "c");
            Assert.AreEqual(-1, new Testing().Compare(a,b));
        }
        [TestMethod]
        public void Test_Compare2()
        {
            Testing a = new Testing("a", "b");
            Testing b = new Testing("a", "b");
            Assert.AreEqual(0, new Testing().Compare(a, b));
        }
        [TestMethod]
        public void Test_Compare3()
        {
            Testing a = new Testing("b", "c");
            Testing b = new Testing("a", "b");
            Assert.AreEqual(1, new Testing().Compare(a, b));
        }
        [TestMethod]
        public void Test_TestingClone()
        {
            Testing a = new Testing();
            a.RandomInit();
            Testing b = (Testing)a.Clone();
            Assert.AreEqual(a, b);
        }
        [TestMethod]
        public void Test_TestClone()
        {
            Test a = new Test();
            a.RandomInit();
            Test b = (Test)a.Clone();
            Assert.AreEqual(a, b);
        }
        [TestMethod]
        public void Test_ExamClone()
        {
            Exam a = new Exam();
            a.RandomInit();
            Exam b = (Exam)a.Clone();
            Assert.AreEqual(a, b);
        }
        [TestMethod]
        public void Test_GraduationExamClone()
        {
            GraduationExam a = new GraduationExam();
            a.RandomInit();
            GraduationExam b = (GraduationExam)a.Clone();
            Assert.AreEqual(a, b);
        }
    }
}
