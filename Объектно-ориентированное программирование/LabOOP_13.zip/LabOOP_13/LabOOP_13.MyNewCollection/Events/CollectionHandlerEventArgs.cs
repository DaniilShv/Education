﻿using TestingLib;

namespace LabOOP_13.MyNewCollection.Events
{
    public delegate void CollectionHandler(object source, CollectionHandlerEventArgs args);
    public class CollectionHandlerEventArgs : EventArgs
    {
        public string NameCollection { get; set; }

        public string Type { get; set; }

        public object Object { get; set; }

        public CollectionHandlerEventArgs(string nameCollection,
            string type, object obj)
        {
            NameCollection = nameCollection;
            Type = type;
            Object = obj;
        }

        public override string ToString()
        {
            return $"Название коллекции: {NameCollection}\n" +
                $"Тип: {Type}\n" +
                $"Ссылка на объект: [\n{Object.ToString()}]\n";
        }
    }
}
