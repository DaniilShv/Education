﻿using BinaryTreeLib;
using LabOOP_13.MyNewCollection.Events;
using NodeTree;
using TestingLib;

namespace LabOOP_13.MyNewCollection
{
    public class MyNewCollection : BinaryTree<Testing>  
    {
        public event CollectionHandler CollectionCountChanged;

        public event CollectionHandler CollectionReferenceChanged;

        public string Name { get; set; }

        public void Add(Testing item)
        {
            base.Add(item);
            CollectionCountChanged?.Invoke(this, new CollectionHandlerEventArgs(Name, "Элемент добавлен", item));
        }

        public void Remove(Testing item)
        {
            base.Remove(item);
            CollectionCountChanged?.Invoke(this, new CollectionHandlerEventArgs(
                Name, "Элемент очищен", item
                ));
        }

        public void Update(Testing item, string newSubject)
        {
            var obj = Update(item, Head);
            obj.data.SubjectName = newSubject;
            CollectionReferenceChanged?.Invoke(this, new CollectionHandlerEventArgs(
                Name, "Элемент перезаписан", obj.data
                ));
        }

        private NodeTree<Testing> Update(Testing item, NodeTree<Testing> node)
        {
            if (node == null)
                return null;
            if (item.Equals(node.data))
                return node;
            if (_comparer.Compare(item, node.data) < 0)
                return Update(item, node.left_ptr);
            else
                return Update(item, node.right_ptr);
        }

        public string this[Testing item]
        {
            set
            {
                Update(item, value);
            }
        }

    }
}
