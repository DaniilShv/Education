﻿namespace LabOOP_13.JournalClass;
public class JournalEntry
{
    public string NameCollection { get; set; }

    public string Type { get; set; }

    public object Object { get; set; }

    public JournalEntry(string nameCollection,
        string type, object obj)
    {
        NameCollection = nameCollection;
        Type = type;
        Object = obj;
    }

    public override string ToString()
    {
        return $"Название коллекции: {NameCollection}\n" +
            $"Тип: {Type}\n" +
            $"Ссылка на объект: [\n{Object.ToString()}]\n";
    }
}
