﻿namespace LabOOP_13.JournalClass;
public class Journal
{
    private List<JournalEntry> _entries;

    public Journal()
    {
        _entries = new List<JournalEntry>();
    }

    public void AddLog(string nameCollection, string type, object obj)
    {
        var entry = new JournalEntry(nameCollection, type, obj);
        _entries.Add(entry);
    }

    public void GetEntries()
    {
        foreach (var entry in _entries)
        {
            Console.WriteLine(entry.ToString());
        }
    }
}
