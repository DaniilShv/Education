﻿using BinaryTreeLib;

namespace LabOOP_13.MyCollection
{
    public class MyCollection<T> : BinaryTree<T> where T : IComparable<T>
    {
        public int Length => Count;
    }
}
