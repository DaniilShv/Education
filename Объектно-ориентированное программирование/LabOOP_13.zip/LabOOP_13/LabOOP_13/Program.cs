﻿using LabOOP_13.JournalClass;
using LabOOP_13.MyNewCollection;
using LabOOP_13.MyNewCollection.Events;
using TestingLib;

var collection = new MyNewCollection();
var journal = new Journal();
collection.CollectionCountChanged += OnEventCount;
collection.CollectionReferenceChanged += OnEventReference;

collection.Add(new Testing("p", "p"));
collection.Add(new Testing("w", "w"));
collection.Remove(new Testing("p", "p"));
collection[new Testing("w", "w")] =  "Foreign language";

journal.GetEntries();
void OnEventCount(object source, CollectionHandlerEventArgs args)
{
    journal.AddLog(args.NameCollection, args.Type, args.Object);
}

void OnEventReference(object source, CollectionHandlerEventArgs args)
{
    journal.AddLog(args.NameCollection, args.Type, args.Object);
}