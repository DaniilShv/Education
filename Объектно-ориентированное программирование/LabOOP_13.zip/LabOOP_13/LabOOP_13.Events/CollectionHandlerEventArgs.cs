﻿using LabOOP_13.MyNewCollection;
using TestingLib;

namespace LabOOP_13.Events
{
    public class CollectionHandlerEventArgs : EventArgs
    {
        public delegate void CollectionHandler(object source, CollectionHandlerEventArgs args);

        public string NameCollection { get; set; }

        public string Type { get; set; }

        public MyNewCollection<Testing> Object { get; set; }

        public CollectionHandlerEventArgs(string nameCollection,
            string type, MyNewCollection<Testing> obj)
        {
            NameCollection = nameCollection;
            Type = type;
            Object = obj;
        }

        public override string ToString()
        {
            return $"Название коллекции: {NameCollection}\n" +
                $"Тип: {Type}\n" +
                $"Ссылка на объект: {Object}\n";
        }
    }
}
