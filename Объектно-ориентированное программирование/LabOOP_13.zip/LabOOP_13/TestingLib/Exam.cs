﻿using System;

namespace TestingLib
{
    public class Exam : Testing
    {
        public int VarNumber { get; set; }
        public Exam() { }
        public Exam(string taskName, string subjectName, int varNumber):base(taskName, subjectName)
        {
            VarNumber = varNumber;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Номер варианта: {VarNumber}");
        }
        public override void RandomInit()
        {
            base.RandomInit();
            VarNumber = rnd.Next(10000000);
        }

        public override string ToString()
        {
            return base.ToString() +
                $"Номер варианта: {VarNumber}\n";
        }
    }
}
