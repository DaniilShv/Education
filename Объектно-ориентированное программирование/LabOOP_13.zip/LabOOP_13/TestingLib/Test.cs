﻿using System;
using System.Security.Cryptography;

namespace TestingLib
{
    public class Test : Testing
    {
        public int CountAnswers { get; set; }
        public Test() { }
        public Test(string taskName, string subjectName, int countAnswers):base(taskName, subjectName)
        {
            CountAnswers = countAnswers;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Количество вариантов ответов: {CountAnswers}");
        }
        public override void RandomInit()
        {
            base.RandomInit();
            CountAnswers = rnd.Next(100);
        }

        public override string ToString()
        {
            return base.ToString() +
                $"Количество ответов: {CountAnswers}\n";
        }
    }
}
