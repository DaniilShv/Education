﻿using BinaryTreeLib;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabOOP_12.Collection.Extension
{
    public static class Extensions
    {
        public static IEnumerable<T> Where_<T>(this BinaryTree<T> tree, Func<T, bool> predicate) where T : IComparable<T>
        {
            var enumarable = tree.GetEnumerable();
            return enumarable.Where(predicate);
        }

        public static decimal Average_<T>(this BinaryTree<T> tree, Func<T, decimal> predicate) where T : IComparable<T>
        {
            var enumarable = tree.GetEnumerable();
            return enumarable.Average(predicate);
        }

        public static IEnumerable<T> OrderBy_<T, TKey>(this BinaryTree<T> tree, Func<T, TKey> predicate) where T : IComparable<T>
        {
            var enumarable = tree.GetEnumerable();
            return enumarable.OrderBy(predicate);
        }

        public static IEnumerable<T> OrderByDescending_<T, TKey>(this BinaryTree<T> tree, Func<T, TKey> predicate) where T : IComparable<T>
        {
            var enumarable = tree.GetEnumerable();
            return enumarable.OrderByDescending(predicate);
        }

        public static IEnumerable<IGrouping<TKey, TElement>> GroupBy_<TElement, TKey>(this BinaryTree<TElement> tree,
            Func<TElement, TKey> function) where TElement : IComparable<TElement>
        {
            var enumarable = tree.GetEnumerable();
            return enumarable.GroupBy(function);
        }
    }
}
