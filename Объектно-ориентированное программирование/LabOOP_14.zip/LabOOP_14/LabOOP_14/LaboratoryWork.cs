﻿using System;
using TestingLib;

namespace LabOOP_14
{
    public class Universities
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }

    public static class LaboratoryWork
    {
        public static void ExecuteLINQWhereExtension(Stack<Dictionary<int, Testing>> gradebook)
        {
            foreach (var item in gradebook)
            {
                foreach (var item1 in item.Where(x => (int)x.Key % 2 == 0))
                {
                    Console.WriteLine("{0}, {1}", item1.Key, item1.Value.ToString());
                }
            }
        }

        public static void ExecuteLINQUnionExtension(
            Stack<Dictionary<int, Testing>> gradebook,
            Stack<Dictionary<int, Testing>> stack)
        {
            foreach (var item in gradebook.Union(stack))
            {
                foreach (var item1 in item)
                {
                    Console.WriteLine("{0}, {1}", item1.Key, item1.Value.ToString());
                }
            }
        }

        public static void ExecuteLINQGroupByExtension(
            IEnumerable<Dictionary<int, Testing>> unionStack)
        {
            foreach (var item in unionStack.SelectMany(x => x).GroupBy(x => new { x.Key }))
            {
                Console.WriteLine(item.Key);
                foreach (var item1 in item)
                {
                    Console.WriteLine("{0}, {1}", item1.Key, item1.Value.ToString());
                }
                Console.WriteLine();
            }
        }

        public static void ExecuteLINQlet(Stack<Dictionary<int, Testing>> gradebook)
        {
            var obj = from i in gradebook
                      from j in i
                      let name = $"Номер семестра: {j.Key}"
                      select new
                      { Name = name, Value = j.Value };
            foreach (var item in obj)
            {
                Console.WriteLine(item.Name + " " + item.Value);
            }
        }

        public static void ExecuteLINQJoinExtension(Stack<Dictionary<int, Testing>> gradebook)
        {
            Universities[] universities = {
                new() { Name = "ПНИПУ", Id = 1},
                new() { Name = "МГУ", Id = 2},
                new() { Name = "МФТИ", Id = 3},
                new() { Name = "СПбГУ", Id = 4},
                new() { Name = "МГТУ", Id = 5}
            };
            var iter = gradebook.SelectMany(x => x).Join(universities,
                g => g.Key,
                u => u.Id,
                (g, u) => new { Name = g.Key, University = u, SubjectName = g.Value });
            foreach (var item in iter)
            {

                Console.WriteLine($"{item.Name}|\t|{item.University.Name}|\t|{item.SubjectName}");
            }
        }

        public static void ExecuteLINQWhere(Stack<Dictionary<int, Testing>> gradebook)
        {
            foreach (var item in gradebook)
            {
                var linq = from x in item
                           where x.Key%2==0
                           select x;
                foreach (var item1 in linq)
                {
                    Console.WriteLine("{0}, {1}", item1.Key, item1.Value.ToString());
                }
            }
        }

        public static void ExecuteLINQUnion(
            Stack<Dictionary<int, Testing>> gradebook,
            Stack<Dictionary<int, Testing>> stack)
        {
            var linq = from i in gradebook.Union(stack)
                       select i;
            foreach (var item in linq)
            {
                foreach (var item1 in item)
                {
                    Console.WriteLine("{0}, {1}", item1.Key, item1.Value.ToString());
                }
            }
        }

        public static void ExecuteLINQGroupBy(
            IEnumerable<Dictionary<int, Testing>> unionStack)
        {
            var linq = from collection in unionStack
                       from item in collection
                       group item by new { item.Key };
                       
            foreach (var item in linq)
            {
                Console.WriteLine(item.Key);
                foreach (var item1 in item)
                {
                    Console.WriteLine("{0}, {1}", item1.Key, item1.Value.ToString());
                }
                Console.WriteLine();
            }
        }

        public static void ExecuteLINQJoin(Stack<Dictionary<int, Testing>> gradebook)
        {
            Universities[] universities = {
                new() { Name = "ПНИПУ", Id = 1},
                new() { Name = "МГУ", Id = 2},
                new() { Name = "МФТИ", Id = 3},
                new() { Name = "СПбГУ", Id = 4},
                new() { Name = "МГТУ", Id = 5}
            };
            var linq = from collection in gradebook
                       from item in collection
                       join univ in universities
                       on item.Key equals univ.Id
                       select new { Name = item.Key, University = univ, SubjectName = item.Value };

            foreach (var item in linq)
            {

                Console.WriteLine($"{item.Name}|\t|{item.University.Name}|\t|{item.SubjectName}");
            }
        }
    }
}
