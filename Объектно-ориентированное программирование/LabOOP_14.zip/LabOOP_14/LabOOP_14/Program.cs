﻿using BinaryTreeLib;
using LabOOP_12.Collection.Extension;
using LabOOP_14;
using System.Diagnostics;
using TestingLib;

Stack<Dictionary<int, Testing>> gradebook = new();

Stack<Dictionary<int, Testing>> stack = new();

for (int i = 1; i < 9; i++)
{
    var item = new Testing();
    item.RandomInit();
    var dict = new Dictionary<int, Testing>();
    dict.Add(i, item);

    gradebook.Push(dict);
}

for (int i = 1; i < 9; i++)
{
    var item = new Testing();
    item.RandomInit();
    var dict = new Dictionary<int, Testing>();
    dict.Add(i, item);

    stack.Push(dict);
}

Console.WriteLine("Сортировка данных по условию:");
Stopwatch sw = new();
long linq_query = 0, linq_extension = 0;
for (int i = 0; i < 5; i++)
{
    sw.Restart();
    LaboratoryWork.ExecuteLINQWhere(gradebook);
    Console.Clear();
    sw.Stop();
    linq_query += sw.ElapsedTicks;
}
sw.Stop();
for (int i = 0; i < 5; i++)
{
    sw.Restart();
    LaboratoryWork.ExecuteLINQWhereExtension(gradebook);
    Console.Clear();
    sw.Stop();
    linq_extension += sw.ElapsedTicks;
}
sw.Stop();
LaboratoryWork.ExecuteLINQWhere(gradebook);
Console.WriteLine("\nСкорость выполнения LINQ:");
Console.WriteLine($"\tLINQ запрос: {linq_query/5}");
Console.WriteLine($"\tLINQ extension: {linq_extension/5}");

Console.WriteLine($"\nСреднее значение из ключей: {gradebook.Average(x => x.Keys.Average())}");

Console.WriteLine("\nОбъединение множеств:");
LaboratoryWork.ExecuteLINQUnionExtension(gradebook, stack);

Console.WriteLine("\nГруппировка:");
var unionStack = gradebook.Union(stack);
LaboratoryWork.ExecuteLINQGroupByExtension(unionStack);

Console.WriteLine("\nКлючевое слово let");
LaboratoryWork.ExecuteLINQlet(gradebook);

Console.WriteLine("\nJoin коллекций");
LaboratoryWork.ExecuteLINQJoinExtension(gradebook);

Console.WriteLine("\nМетоды расширения коллекции");

ExecuteBinaryTreeQuery();

void ExecuteBinaryTreeQuery()
{
    BinaryTree<Exam> tree = new();
    for (int i = 0; i < 20; i++)
    {
        var obj = new Exam();
        obj.RandomInit();
        tree.Add(obj);
    }

    var query = tree.Where_(x => x.SubjectName[0] == 'И');

    foreach (var item in query)
    {
        Console.WriteLine(item);
    }

    Console.WriteLine(tree.Average_(x => x.VarNumber));

    var orderBy = tree.OrderBy_(x => x.SubjectName);

    var orderByDescending = tree.OrderByDescending_(x => x.SubjectName);

    Console.WriteLine("\nУпорядочивание по названию предмета:");
    foreach (var item in orderBy)
    {
        Console.WriteLine(item);
    }

    Console.WriteLine("\nУпорядочивание по названию предмета:");
    foreach (var item in orderByDescending)
    {
        Console.WriteLine(item);
    }

    Console.WriteLine("\nГруппировка данных:");

    var groupTree = tree.GroupBy_(x => new { x.SubjectName });
    foreach (var item in groupTree)
    {
        Console.WriteLine(item.Key);
        foreach (var item1 in item)
        {
            Console.WriteLine(item1.SubjectName + " " + item1.Task);
        }
        Console.WriteLine();
    }
}