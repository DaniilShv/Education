﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LabDisk_1
{
    enum sets_num { 
        A = 0,
        B = 1,
        C = 2,
        D = 3,
        E = 4
    }
    public class Set
    {
        List<int> _list = new List<int>();
        public int Size { get; private set; }

        public bool Add(int element)
        {
            bool repeat = false;
            for (int i = 0; i < _list.Count && !repeat; ++i)
            {
                if (_list[i] == element) repeat = true;
            }
            if (!repeat) { _list.Add(element); ++Size; }
            return repeat;
        }
        public void Copy(Set set)
        {
            for (int i = 0; i < set.Size; i++)
            {
                _list.Add(set[i]);
                ++Size;
            }
        }
        public int this[int i] //перегрузка []
        {
            get { return _list[i]; }
            set { _list[i] = value; }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Вас приветствует калькулятор множеств!\n");

            List<Set> sets = new List<Set>();
            Set universum = new Set();
            while (true)
            {
                Console.Write("Выберите операцию:\n" +
                    "1. Пересечение\n" +
                    "2. Объединение\n" +
                    "3. Разность\n" +
                    "4. Симметрическая разность\n" +
                    "5. Дополнение\n" +
                    "6. Добавить множество\n" +
                    "7. Определить универсум\n");

                OutOnTheScreenList(ref sets);
                OutUniversum(ref universum);
                Console.Write(">");

                int index_set1;
                int index_set2;
                Set res = new Set(); //результат действий над множествами

                try
                {
                    int switcher = Convert.ToInt32(Console.ReadLine());
                    switch (switcher)
                    {
                        case 1:
                            Console.Write("Укажите первое множество: ");
                            index_set1 = KnowIndex(Console.ReadLine(), ref sets);
                            Console.Write("Укажите второе множество: ");
                            index_set2 = KnowIndex(Console.ReadLine(), ref sets);
                            if (index_set1 == -1 || index_set2 == -1)
                            {
                                Console.WriteLine("Введите корректно название множества");
                                Console.ReadLine();
                                break;
                            }
                            for (int i = 0; i < sets[index_set1].Size; i++)
                            {
                                bool repeat = false;
                                for (int j = 0; j < sets[index_set2].Size && !repeat; j++)
                                {
                                    if (sets[index_set1][i] == sets[index_set2][j])
                                    {
                                        repeat = true;
                                    }
                                }
                                if (repeat) res.Add(sets[index_set1][i]);
                            }
                            Console.Clear();
                            OutOnTheScreenSet(ref res);
                            Console.ReadLine();
                            break; //Пересечение
                        case 2:
                            Console.Write("Укажите первое множество: ");
                            index_set1 = KnowIndex(Console.ReadLine(), ref sets);
                            Console.Write("Укажите второе множество: ");
                            index_set2 = KnowIndex(Console.ReadLine(), ref sets);
                            if (index_set1 == -1 || index_set2 == -1)
                            {
                                Console.WriteLine("Введите корректно название множества");
                                Console.ReadLine();
                                break;
                            }
                            res.Copy(sets[index_set1]);
                            for (int i = 0; i < sets[index_set2].Size; i++)
                            {
                                bool repeat = false;
                                for (int j = 0; j < res.Size && !repeat; j++)
                                {
                                    if (sets[index_set2][i] == res[j])
                                    {
                                        repeat = true;
                                    }
                                }
                                if (!repeat) res.Add(sets[index_set2][i]);
                            }
                            Console.Clear();
                            OutOnTheScreenSet(ref res);
                            Console.ReadLine();
                            break; //Объединение
                        case 3:
                            Console.Write("Укажите первое множество: ");
                            index_set1 = KnowIndex(Console.ReadLine(), ref sets);
                            Console.Write("Укажите второе множество: ");
                            index_set2 = KnowIndex(Console.ReadLine(), ref sets);
                            if (index_set1 == -1 || index_set2 == -1)
                            {
                                Console.WriteLine("Введите корректно название множества");
                                Console.ReadLine();
                                break;
                            }
                            for (int i = 0; i < sets[index_set1].Size; i++)
                            {
                                bool repeat = false;
                                for (int j = 0; j < sets[index_set2].Size && !repeat; j++)
                                {
                                    if (sets[index_set1][i] == sets[index_set2][j])
                                    {
                                        repeat = true;
                                    }
                                }
                                if (!repeat) res.Add(sets[index_set1][i]);
                            }
                            Console.Clear();
                            OutOnTheScreenSet(ref res);
                            Console.ReadLine();
                            break; //Разность
                        case 4:
                            Console.Write("Укажите первое множество: ");
                            index_set1 = KnowIndex(Console.ReadLine(), ref sets);
                            Console.Write("Укажите второе множество: ");
                            index_set2 = KnowIndex(Console.ReadLine(), ref sets);
                            if (index_set1 == -1 || index_set2 == -1)
                            {
                                Console.WriteLine("Введите корректно название множества");
                                Console.ReadLine();
                                break;
                            }
                            for (int i = 0; i < sets[index_set1].Size; i++)
                            {
                                bool repeat = false;
                                for (int j = 0; j < sets[index_set2].Size && !repeat; j++)
                                {
                                    if (sets[index_set1][i] == sets[index_set2][j])
                                    {
                                        repeat = true;
                                    }
                                }
                                if (!repeat) res.Add(sets[index_set1][i]);
                            }
                            for (int i = 0; i < sets[index_set2].Size; i++)
                            {
                                bool repeat = false;
                                for (int j = 0; j < sets[index_set1].Size && !repeat; j++)
                                {
                                    if (sets[index_set2][i] == sets[index_set1][j])
                                    {
                                        repeat = true;
                                    }
                                }
                                if (!repeat) res.Add(sets[index_set2][i]);
                            }
                            Console.Clear();
                            OutOnTheScreenSet(ref res);
                            Console.ReadLine();
                            break; //Симметричная разность
                        case 5:
                            Console.Write("Укажите множество: ");
                            index_set1 = KnowIndex(Console.ReadLine(), ref sets);
                            if (index_set1 == -1)
                            {
                                Console.WriteLine("Введите корректно название множества");
                                Console.ReadLine();
                                break;
                            }
                            for (int i = 0; i < universum.Size; i++)
                            {
                                bool repeat = false;
                                for (int j = 0; j < sets[index_set1].Size && !repeat; j++)
                                {
                                    if (sets[index_set1][j] == universum[i])
                                    {
                                        repeat = true;
                                    }
                                }
                                if (!repeat) res.Add(universum[i]);
                            }
                            Console.Clear();
                            OutOnTheScreenSet(ref res);
                            Console.ReadLine();
                            break; //Дополнение
                        case 6:
                            Console.Write("1. Сгенерировать множество\n" +
                        "2. Ввести вручную\n");
                            try
                            {
                                switcher = Convert.ToInt32(Console.ReadLine());
                            }
                            catch
                            {
                                Console.WriteLine("Пункт меню выбран некорректно (введите целое число)");
                                Console.ReadLine();
                            }
                            switch (switcher)
                            {
                                case 1:
                                    Console.Write("Введите количество элементов: ");
                                    try
                                    {
                                        int count = Convert.ToInt32(Console.ReadLine());
                                        sets.Add(new Set());
                                        for (int i = 0; i < count; ++i)
                                        {
                                            bool pr = sets[sets.Count - 1].Add(new Random().Next(100));
                                            if (pr) { --i; }
                                        }
                                    }
                                    catch
                                    {
                                        Console.WriteLine("Количество элементов должно быть целым числом");
                                        Console.ReadLine();
                                    }

                                    break;
                                case 2:

                                    Console.Write("Введите количество элементов: ");
                                    try
                                    {
                                        int count = Convert.ToInt32(Console.ReadLine());
                                        sets.Add(new Set());
                                        for (int i = 0; i < count; i++)
                                        {
                                            try
                                            {
                                                bool pr = sets[sets.Count - 1].Add(Convert.ToInt32(Console.ReadLine()));
                                                if (pr) { --i; Console.WriteLine("Такой элемент содержится в множестве"); }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Введите целое число!");
                                                --i;
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        Console.WriteLine("Количество элементов должно быть целым числом");
                                        Console.ReadLine();
                                    }
                                    break;
                            }
                            break; //Добавление
                        case 7:
                            Console.Write("1. Сгенерировать множество\n" +
                        "2. Ввести вручную\n");
                            switcher = Convert.ToInt32(Console.ReadLine());
                            switch (switcher)
                            {
                                case 1:
                                    Console.Write("Введите количество элементов: ");
                                    int count = Convert.ToInt32(Console.ReadLine());
                                    for (int i = 0; i < count; ++i)
                                    {
                                        universum.Add(i);
                                    }
                                    break;
                                case 2:
                                    Console.Write("Введите количество элементов: ");
                                    count = Convert.ToInt32(Console.ReadLine());
                                    for (int i = 0; i < count; i++)
                                    {
                                        bool pr = universum.Add(Convert.ToInt32(Console.ReadLine()));
                                        if (pr) { --i; Console.WriteLine("Такой элемент содержится в множестве"); }
                                    }
                                    break;
                            }
                            break; //Добавление универсума
                    }
                }
                catch
                {
                    Console.WriteLine("Выберите корректно пункт меню");
                    Console.ReadLine();
                }
                Console.Clear();
            }
        }
        static void OutOnTheScreenList(ref List<Set> sets) //вывод всех множеств
        {
            if (sets.Count == 0) return;
            for (int i = 0; i < sets.Count; i++)
            {
                Console.Write($"{(sets_num)i} = " + "{");
                for (int j = 0; j < sets[i].Size; j++)
                {
                    Console.Write(sets[i][j]);
                    if (!(j == sets[i].Size - 1)) { Console.Write(", "); }
                }
                Console.Write("}");
                Console.WriteLine();
            }
            Console.WriteLine();
        }
        static int KnowIndex(string a, ref List<Set> k) //узнать индекс массива по названию
        {

            switch(a)
            {
                case "A":
                    if (k.Count >= (int)sets_num.A) 
                        return (int)sets_num.A;
                    break;
                case "B":
                    if (k.Count >= (int)sets_num.B)
                        return (int)sets_num.B;
                    break;
                case "C":
                    if (k.Count >= (int)sets_num.C)
                        return (int)sets_num.C;
                    break;
                case "D":
                    if (k.Count >= (int)sets_num.D)
                        return (int)sets_num.D;
                    break;
                case "E":
                    if (k.Count >= (int)sets_num.E)
                        return (int)sets_num.E;
                    break;
            }
            return -1;
        }
        static void OutOnTheScreenSet(ref Set set)
        {
            Console.Write("Результат = {");
            for (int j = 0; j < set.Size; j++)
            {
                Console.Write(set[j]);
                if (!(j == set.Size - 1)) { Console.Write(", "); }
            }
            Console.Write("}");
        }   //Вывод множества в консоль
        static void OutUniversum(ref Set set)
        {
            if (set.Size == 0) return;
            Console.Write("U = {");
            for (int j = 0; j < set.Size; j++)
            {
                Console.Write(set[j]);
                if (!(j == set.Size - 1)) { Console.Write(", "); }
            }
            Console.Write("}");
            Console.WriteLine();
        } //Вывод множества универсум
    }
}
