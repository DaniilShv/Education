﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TestingLib
{
    public class Testing : IInit, IComparable<Testing>, ICloneable
    {
        protected static Random rnd = new Random();
        public string SubjectName { get; set; }
        public string Task { get; set; }
        protected string[] subjectNames = { "Алгебра", "Дискретная математика", "Информатика", "Алгоритмизация", "Проектирование", "Физика", "Геометрия",
        "Проектирование информационных систем", "Алгебра множеств", "Алгебра логики", "Математический анализ", "Квантовая физика",
        "Термодинамика", "Комбинаторика", "Векторная алгебра", "Высшая математика", "Программирование", "Теория алгоритмов", "Астрофизика",
        "Линейная алгебра", "Прикладная математика", "Прикладное программирование", "Теория чисел", "Вычислительная техника",
        "Теоретическая информатика", "Кибернетика", "Механика", "Электротехника", "Электроника", "Микроэлектроника", "Робототехника",
        "Искусственный интеллект", "Прикладная механика", "Проектирование ИИ", "Алгебра программирования", "Проектирование алгоритмов"};
        protected string[] taskNames = { "Посчитать", "Решить задание", "Сделать рисунок", "Нарисовать схему", "Начертить схему", "Придумать задание", 
            "Написать алгоритм", "Посчитать количество", "Решить уравнение", "Доказать теорему", "Доказать формулу", "Доказать тождество",
        "Перевести в двоичную систему счисления", "Перевести в восьмеричную систему счисления", "Перевести в десятичную систему счисления",
        "Перевести в шестнадцатеричную систему счисления", "Собрать схему", "Написать программу", "Запрограммировать алгоритм",
        "Написать на языке C#", "Написать на языке Java", "Написать на языке C++", "Написать на языке Python", "Нарисовать диаграмму", "Вывести диаграмму в консоль",
        "Сделать пользовательский интерфейс", "Разработать графический интерфейс", "Написать функцию"};
        public Testing() { }
        public Testing(string taskName, string subjectName)
        {
            SubjectName = subjectName;
            Task = taskName;
        }
        public void Init(string taskName, string subjectName)
        {
            Task = taskName;
            SubjectName = subjectName;
        }
        public virtual void RandomInit()
        {
            SubjectName = subjectNames[rnd.Next(subjectNames.Length)];
            Task = taskNames[rnd.Next(taskNames.Length)];
        }
        public int CompareTo(Testing testing)
        {
            if (testing is null)
                throw new ArgumentNullException("Объект ссылается на null");
            if (SubjectName.CompareTo(testing.SubjectName) == 0){
                return Task.CompareTo(testing.Task);
            }
            return SubjectName.CompareTo(testing.SubjectName);
        }
        public T ShallowCopy<T>()
        {
            return (T)this.MemberwiseClone();
        }
        public object Clone() => new Testing(Task, SubjectName);
        public virtual void ShowInfo()
        {
            Console.WriteLine($"Название предмета: {SubjectName}");
            Console.WriteLine($"Задание: {Task}");
        }
        public override string ToString()
        {
            return SubjectName + " " + Task;
        }
        public override bool Equals(object obj)
        {
            if (obj is Testing test)
                if (test.SubjectName == SubjectName && test.Task == Task)
                    return true;
            return false;
        }
    }
    public class Test : Testing
    {
        public int CountAnswers { get; set; }

        public Testing BaseTesting
        {
            get { return new Testing(Task, SubjectName); }
        }
        public Test() { }
        public Test(string taskName, string subjectName, int countAnswers):base(taskName, subjectName)
        {
            CountAnswers = countAnswers;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Количество вариантов ответов: {CountAnswers}");
        }
        public override string ToString()
        {
            return SubjectName + " " + Task + " " + CountAnswers;
        }
        public override void RandomInit()
        {
            base.RandomInit();
            CountAnswers = rnd.Next(10);
        }
    }
    public class Exam : Testing
    {
        public int VarNumber { get; set; }
        public Testing BaseTesting
        {
            get { return new Testing(Task, SubjectName); }
        }
        public Exam(string taskName, string subjectName, int varNumber):base(taskName, subjectName)
        {
            VarNumber = varNumber;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Номер варианта: {VarNumber}");
        }
        public override void RandomInit()
        {
            base.RandomInit();
            VarNumber = rnd.Next(100);
        }
    }
    public class GraduationExam : Exam
    {
        public int IdentifyNumber { get; set; }
        public GraduationExam(string taskName, string subjectName, int varNumber, int identifyNumber)
            : base(taskName, subjectName, varNumber)
        {
            IdentifyNumber = identifyNumber;
        }
        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine($"Идентификатор: {IdentifyNumber}");
        }
        public override void RandomInit()
        {
            base.RandomInit();
            IdentifyNumber = rnd.Next(1000000, 10000000);
        }
    }
}
