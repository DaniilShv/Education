﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab_5
{
    static class Task1
    {
        static public void Execute()
        {
            Console.WriteLine("1 Задание\n(Перейти к следующему заданию F3)" +
                "\nНажмите любую клавишу для продолжения");
            if (Console.ReadKey().Key == ConsoleKey.F3) 
            { 
                Console.Clear(); 
                return; 
            }
            Console.Clear();
            int switcher, length = 0;
            bool isCreate = false;
            int[] arr = null;
            while (true)
            {
                Console.WriteLine("1 Задание");

                Console.Write("1. Создать новый массив\n" +
                    "2. Заполнить массив числами\n" +
                    "3. Вывести массив на экран\n" +
                    "4. Удалить элементы массива\n" +
                    "5. Выход\n" +
                    ">");

                while (!inputSwitcher(out switcher)) { }

                switch (switcher)
                {
                    case 1:
                        int lenght;
                        Console.Write("Введите количество элементов в массиве: ");
                        while (!int.TryParse(Console.ReadLine(), out lenght) || lenght < 1)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write("Введите целое неотрицательное число\n(количество элементов > 0): ");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        createArray(out arr, lenght);
                        isCreate = true;
                        Console.WriteLine($"Создан массив на {arr.Length} элементов");
                        Console.ReadLine();
                        break;
                    case 2:
                        if (!isCreate)
                        {
                            Console.WriteLine("Сначала создайте массив");
                            Console.ReadLine();
                            break;
                        }
                        Console.Write("1. Создать массив вручную\n" +
                            "2. Сгенерировать массив\n" +
                            ">");
                        while (!int.TryParse(Console.ReadLine(), out switcher) || switcher < 1 || switcher > 2)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write("Введите корректно пункт меню: ");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        switch (switcher)
                        {
                            case 1:
                                fillArray(ref arr);
                                Console.WriteLine("Массив сгенерирован");
                                Console.ReadLine();
                                break;
                            case 2:
                                fillArrayRnd(ref arr);
                                Console.WriteLine("Массив сгенерирован");
                                Console.ReadLine();
                                break;
                        }
                        break;
                    case 3:
                        if (!isCreate)
                        {
                            Console.WriteLine("Сначала создайте массив");
                            Console.ReadLine();
                            break;
                        }
                        printArray(ref arr);
                        Console.ReadLine();
                        break;
                    case 4:
                        if (!isCreate)
                        {
                            Console.WriteLine("Сначала создайте массив");
                            Console.ReadLine();
                            break;
                        }
                        printArray(ref arr);
                        int number;
                        Console.WriteLine("Введите с какого номера удалить элемент: ");
                        while (!int.TryParse(Console.ReadLine(), out number) || number < 1 || number > arr.Length)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            if (number > length)
                                Console.Write($"Номер элемента не должен превышать размер массива\n(размер массива {arr.Length}): ");
                            else
                                Console.Write("Введите целое неотрицательное число\n(количество элементов > 0): ");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                        deleteSomeElements(ref arr, number);
                        Console.WriteLine($"Новый размер массива: {number - 1} элемента");
                        Console.ReadLine();
                        break;
                    case 5:
                        Console.WriteLine("Чтобы выйти нажмите F4");
                        if (Console.ReadKey().Key == ConsoleKey.F4)
                        {
                            Console.Clear();
                            return;
                        }
                        break;
                }
                Console.Clear();
            }
        }
        static void fillArrayRnd(ref int[] arr)
        {
            Random rnd = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rnd.Next(-100,100);
            }
        }
        static void fillArray(ref int[] arr)
        {
            int value;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"Введите {i+1} элемент: ");
                while (!int.TryParse(Console.ReadLine(), out value))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Введите целое число: ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
                arr[i] = value;
            }
        }
        static void printArray(ref int[] arr)
        {
            if (arr.Length == 0)
                Console.WriteLine("Пустой массив");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i]);
                Console.Write(" ");
            }
            Console.WriteLine();
        }
        static int[] deleteSomeElements(ref int[] arr, int num)
        {
            int[] temp_arr = new int[num-1];
            for (int i = 0; i < num - 1; i++)
            {
                temp_arr[i] = arr[i];
            }
            arr = temp_arr;
            return arr;
        }
        static void createArray(out int[] arr, int lenght)
        {
            arr = new int[lenght];
        }
        static bool inputSwitcher(out int switcher)
        {
            if (int.TryParse(Console.ReadLine(), out switcher))
            {
                if (switcher < 1 || switcher > 5)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Введите корректно пункт меню: ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    return false;
                }
                return true;
            }
            else 
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Введите корректно пункт меню: ");
                Console.ForegroundColor = ConsoleColor.Gray;
                return false;
            }
        }
    }
}
