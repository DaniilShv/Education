﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab_5
{
    static class Task3
    {
        static public void Execute()
        {
            int[][] arr = null;
            bool isCreated = false;
            Console.WriteLine("3 Задание\n(Чтобы выйти нажмите F4)" +
                    "\nНажмите любую клавишу для продолжения");
            if (Console.ReadKey().Key == ConsoleKey.F4)
            {
                Console.Clear();
                return;
            }
            while (true)
            {
                Console.Clear();
                Console.WriteLine("3 Задание");
                Console.WriteLine("Нажмите F5, чтобы создать новый массив");
                if (isCreated)
                {
                    Console.WriteLine("Для продолжения нажмите любую клавишу");
                }
                if (Console.ReadKey().Key == ConsoleKey.F5)
                {
                    isCreated = true;
                    createArray(ref arr);
                    fillArray(ref arr);
                }
                if (!isCreated)
                {
                    Console.Clear();
                    continue;
                }
                printArray(ref arr);
                Console.Write("Добавить строки - F5\nЧтобы выйти нажмите F4\n");
                ConsoleKeyInfo key = Console.ReadKey();
                if (key.Key == ConsoleKey.F5)
                {
                    int number, count;
                    Console.Write("Введите номер строки: ");
                    while (!int.TryParse(Console.ReadLine(), out number) || number < 1 || number > arr.Length)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("Введите целое неотрицательное число" +
                            "\n(Номер строки не должен превышать количество строк): ");
                        Console.ForegroundColor = ConsoleColor.Gray;
                    }
                    Console.Write("Введите количество строк: ");
                    while (!int.TryParse(Console.ReadLine(), out count) || count < 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("Введите целое неотрицательное число: ");
                        Console.ForegroundColor = ConsoleColor.Gray;
                    }
                    addRowsArray(ref arr, number, count);
                    Console.WriteLine();
                    printArray(ref arr);
                    Console.WriteLine("Чтобы выйти нажмите F4");
                    Console.WriteLine("Нажмите любую клавишу для продолжения");
                    if (Console.ReadKey().Key == ConsoleKey.F4)
                    {
                        Console.Clear();
                        break;
                    }
                }
                if (key.Key == ConsoleKey.F4)
                    break;
                Console.ReadLine();
                Console.Clear();
            }
        }
        static void createArray(ref int[][] arr)
        {
            int row, column;
            Console.Write("Введите количество строк: ");
            while (!int.TryParse(Console.ReadLine(), out row) || row <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Введите целое неотрицательное число (> 0): ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            arr = new int[row][];
            for (int i = 0; i < row; ++i)
            {
                Console.Write($"Введите количество столбцов ({i+1} строка): ");
                while (!int.TryParse(Console.ReadLine(), out column) || column <= 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Введите целое неотрицательное число (> 0): ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
                arr[i] = new int[column];
            }
        }
        static void printArray(ref int[][] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    Console.Write(arr[i][j] + " ");
                }
                Console.WriteLine();
            }
        }
        static void fillArray(ref int[][] arr)
        {
            Random rnd = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    arr[i][j] = rnd.Next(100);
                }
            }
        }
        static void addRowsArray(ref int[][] arr, int number, int count)
        {
            int[][] temp_arr = new int[arr.Length + count][];
            int indexRow = 0;
            for (; indexRow < number; indexRow++)
            {
                temp_arr[indexRow] = new int[arr[indexRow].Length];
            }
            for (int i = 0; i < count; i++)
            {
                temp_arr[i+number] = new int[5];
            }
            for (int i = number+count; i < temp_arr.Length; i++)
            {
                temp_arr[i] = new int[arr[indexRow].Length];
                indexRow++;
            }

            int k = 0;
            for (; k < number; k++)
            {
                for (int j = 0; j < temp_arr[k].Length; j++)
                {
                    temp_arr[k][j] = arr[k][j];
                }
            }
            k += count;
            for (; k < temp_arr.Length; k++)
            {
                for (int j = 0; j < temp_arr[k].Length; j++)
                {
                    temp_arr[k][j] = arr[k-count][j];
                }
            }
            arr = temp_arr;
        }
    }
}
