﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Task1.Execute();
            Task2.Execute();
            Task3.Execute();
        }
    }
}
