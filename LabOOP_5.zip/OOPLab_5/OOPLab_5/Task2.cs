﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPLab_5
{
    static class Task2
    {
        static public void Execute()
        {
            Console.WriteLine("2 Задание\n(Перейти к следующему заданию F3)" +
                "\nНажмите любую клавишу для продолжения");
            if (Console.ReadKey().Key == ConsoleKey.F3)
            {
                Console.Clear();
                return;
            }
            Console.Clear();
            int[,] arr = null;
            bool isCreated = false;
            while (true)
            {
                Console.WriteLine("2 Задание");
                Console.WriteLine("Нажмите F5, чтобы создать новый массив");
                if (isCreated)
                {
                    Console.WriteLine("Для продолжения нажмите любую клавишу");
                }
                if (Console.ReadKey().Key == ConsoleKey.F5)
                {
                    isCreated = true;
                    createArray(ref arr);
                    fillArray(ref arr);
                }
                if (!isCreated)
                {
                    Console.Clear();
                    continue;
                }
                printArray(ref arr);
                Console.Write("Добавить столбцы - F5\nЧтобы выйти нажмите F4\n");
                ConsoleKeyInfo key = Console.ReadKey();
                if (key.Key == ConsoleKey.F5)
                {
                    addColumnArray(ref arr);
                    Console.WriteLine();
                    printArray(ref arr);
                }
                if (key.Key == ConsoleKey.F4)
                    break;
                Console.WriteLine("Нажмите любую клавишу для продолжения");
                Console.ReadLine();
                Console.Clear();
            }
        }
        static void createArray(ref int[,] arr)
        {
            int row, column;
            Console.Write("Введите количество строк: ");
            while (!int.TryParse(Console.ReadLine(), out row) || row <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Введите целое неотрицательное число (> 0): ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            Console.Write("Введите количество столбцов: ");
            while (!int.TryParse(Console.ReadLine(), out column) || column <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Введите целое неотрицательное число (> 0): ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            arr = new int[row, column];
        }
        static void printArray(ref int[,] arr)
        {
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    Console.Write(arr[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
        static void fillArray(ref int[,] arr)
        {
            Random rnd = new Random();
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    arr[i, j] = rnd.Next(100);
                }
            }
        }
        static void addColumnArray(ref int[,] arr)
        {
            int[,] temp_arr = new int[arr.GetLength(0), arr.GetLength(1) + arr.GetLength(1)/2];
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                int column = 0;
                for (int j = 0; j < temp_arr.GetLength(1); j++)
                {
                    if (j == 0)
                        temp_arr[i,j] = arr[i, column++];
                    else
                        if ((j + 1) % 3 != 0)
                            temp_arr[i, j] = arr[i, column++];
                }
            }
            arr = temp_arr;
        }
    }
}
